#!/bin/bash

# 🚀 Sistem Manajemen Aset IT - Setup Script
# Script otomatis untuk instalasi dari nol

echo "🎯 Sistem Manajemen Aset IT - Setup Script"
echo "=========================================="

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js tidak ditemukan. Silakan install Node.js 18+ terlebih dahulu."
    echo "📥 Download: https://nodejs.org/"
    exit 1
fi

# Check Node.js version
NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo "❌ Node.js versi 18+ diperlukan. Versi saat ini: $(node -v)"
    exit 1
fi

echo "✅ Node.js $(node -v) terdeteksi"

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "❌ npm tidak ditemukan."
    exit 1
fi

echo "✅ npm $(npm -v) terdeteksi"

# Create project directory
PROJECT_NAME="manajemen-aset-it"
echo ""
echo "📁 Membuat project directory: $PROJECT_NAME"

if [ -d "$PROJECT_NAME" ]; then
    echo "⚠️  Directory $PROJECT_NAME sudah ada. Menghapus versi lama..."
    rm -rf "$PROJECT_NAME"
fi

mkdir "$PROJECT_NAME"
cd "$PROJECT_NAME"

# Initialize Next.js project
echo ""
echo "🚀 Menginisialisasi Next.js project..."
npx create-next-app@latest . --typescript --tailwind --eslint --app --src-dir --import-alias "@/*" --no-git

# Install additional dependencies
echo ""
echo "📦 Menginstall dependencies..."
npm install @prisma/client prisma
npm install next-auth
npm install zustand @tanstack/react-query
npm install lucide-react
npm install class-variance-authority clsx tailwind-merge

# Install shadcn/ui
echo ""
echo "🎨 Menginstall shadcn/ui components..."
npx shadcn-ui@latest init --yes
npx shadcn-ui@latest add button card input label select textarea table dialog badge

# Setup Prisma
echo ""
echo "🗄️ Setup Prisma database..."
npx prisma init --datasource-provider sqlite

# Create Prisma schema
echo ""
echo "📝 Membuat database schema..."
cat > prisma/schema.prisma << 'EOF'
// This is your Prisma schema file,
// learn more about it in the docs: https://pris.ly/d/prisma-schema

generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "sqlite"
  url      = "file:./dev.db"
}

model User {
  id        String   @id @default(cuid())
  email     String   @unique
  name      String
  password  String
  role      String   @default("user")
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  assets         Asset[]
  assetHistories AssetHistory[]
}

model Asset {
  id            String   @id @default(cuid())
  nama_aset     String
  kategori      String
  merk          String?
  model         String?
  serial_number String?
  no_asset_acc  String?
  status        String   @default("Baik")
  catatan       String?
  gambar_url    String?
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt
  userId        String

  user          User           @relation(fields: [userId], references: [id])
  assetRadio    AssetRadio?
  assetGeneral  AssetGeneral?
  assetHistories AssetHistory[]

  @@map("assets")
}

model AssetRadio {
  id            String   @id @default(cuid())
  nama_aset     String
  unit_code     String?
  nama_unit     String?
  jenis_unit    String?
  model         String?
  serial_number String?
  no_asset_acc  String?
  ur            String?
  po            String?
  status        String   @default("Baik")
  catatan       String?
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt
  assetId       String   @unique

  asset         Asset @relation(fields: [assetId], references: [id], onDelete: Cascade)

  @@map("asset_radios")
}

model AssetGeneral {
  id         String   @id @default(cuid())
  user_name  String?
  nik        String?
  department String?
  createdAt  DateTime @default(now())
  updatedAt  DateTime @updatedAt
  assetId    String   @unique

  asset      Asset @relation(fields: [assetId], references: [id], onDelete: Cascade)

  @@map("asset_generals")
}

model AssetHistory {
  id        String   @id @default(cuid())
  assetId   String
  userId    String
  pengguna  String?
  status    String?
  catatan   String?
  tanggal   DateTime @default(now())
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  asset     Asset @relation(fields: [assetId], references: [id], onDelete: Cascade)
  user      User  @relation(fields: [userId], references: [id])

  @@map("asset_histories")
}
EOF

# Create environment file
echo ""
echo "🔧 Membuat environment variables..."
cat > .env.local << 'EOF'
# Database
DATABASE_URL="file:./dev.db"

# NextAuth
NEXTAUTH_SECRET="your-secret-key-change-this-in-production"
NEXTAUTH_URL="http://localhost:3000"

# Z-AI Web Dev SDK (optional)
ZAI_API_KEY="your-zai-api-key"
EOF

# Create database connection
echo ""
echo "🔌 Membuat database connection..."
mkdir -p src/lib
cat > src/lib/db.ts << 'EOF'
import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const db = globalForPrisma.prisma ?? new PrismaClient()

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
EOF

# Generate Prisma client
echo ""
echo "⚙️ Generate Prisma client..."
npx prisma generate

# Create database
echo ""
echo "💾 Membuat database..."
npx prisma db push

# Create seed script
echo ""
echo "🌱 Membuat seed script..."
mkdir -p src/app/api/seed
cat > src/app/api/seed/route.ts << 'EOF'
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST() {
  try {
    // Create default user
    const user = await db.user.upsert({
      where: { email: 'admin@example.com' },
      update: {},
      create: {
        email: 'admin@example.com',
        name: 'Admin',
        password: 'temp', // In production, hash this
        role: 'admin'
      }
    })

    // Sample assets
    const sampleAssets = [
      {
        nama_aset: 'Radio HT Motorola',
        kategori: 'Radio HT',
        merk: 'Motorola',
        model: 'GP328D',
        serial_number: 'HT001',
        status: 'Baik',
        userId: user.id,
        assetGeneral: {
          create: {
            user_name: 'John Doe',
            nik: '12345',
            department: 'ICTs'
          }
        }
      },
      {
        nama_aset: 'Radio RIG HDKM785',
        kategori: 'Radio RIG',
        merk: 'Hytera',
        model: 'HDKM785',
        serial_number: 'RIG001',
        status: 'Baik',
        userId: user.id,
        assetRadio: {
          create: {
            nama_aset: 'Radio RIG HDKM785',
            unit_code: 'EX001',
            nama_unit: 'Excavator PC2000',
            jenis_unit: 'EXCA PC2000',
            model: 'HDKM785',
            serial_number: 'RIG001',
            status: 'Baik'
          }
        }
      },
      {
        nama_aset: 'Laptop Dell Latitude',
        kategori: 'Laptop',
        merk: 'Dell',
        model: 'Latitude 5420',
        serial_number: 'LAP001',
        status: 'Baik',
        userId: user.id,
        assetGeneral: {
          create: {
            user_name: 'Jane Smith',
            nik: '67890',
            department: 'FINs'
          }
        }
      }
    ]

    for (const asset of sampleAssets) {
      await db.asset.create({ data: asset })
    }

    return NextResponse.json({ 
      message: 'Database seeded successfully',
      assetsCreated: sampleAssets.length 
    })
  } catch (error) {
    console.error('Seeding error:', error)
    return NextResponse.json(
      { error: 'Failed to seed database' },
      { status: 500 }
    )
  }
}
EOF

# Create health check
echo ""
echo "🏥 Membuat health check endpoint..."
mkdir -p src/app/api/health
cat > src/app/api/health/route.ts << 'EOF'
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    await db.$queryRaw`SELECT 1`
    return NextResponse.json({ 
      status: 'healthy',
      timestamp: new Date().toISOString(),
      database: 'connected'
    })
  } catch (error) {
    return NextResponse.json(
      { 
        status: 'unhealthy',
        error: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}
EOF

# Copy source files (if they exist in parent directory)
echo ""
echo "📋 Menyalin source files..."
if [ -f "../src/app/page.tsx" ]; then
    cp -r ../src/* src/
    echo "✅ Source files berhasil disalin"
else
    echo "⚠️  Source files tidak ditemukan. Menggunakan template default..."
fi

# Install dependencies again (in case of new additions)
echo ""
echo "🔄 Installing all dependencies..."
npm install

# Run linting
echo ""
echo "🔍 Running code quality check..."
npm run lint

echo ""
echo "🎉 Setup selesai!"
echo "=================="
echo ""
echo "📋 Langkah selanjutnya:"
echo "1. cd $PROJECT_NAME"
echo "2. npm run dev"
echo "3. Buka http://localhost:3000"
echo "4. (Opsional) Seed data: curl http://localhost:3000/api/seed"
echo ""
echo "📚 Documentation:"
echo "- Tutorial lengkap: TUTORIAL_PASANG.md"
echo "- Quick start: QUICK_START.md"
echo "- README: README.md"
echo ""
echo "🚀 Selamat menggunakan Sistem Manajemen Aset IT!"
echo ""

# Ask if user wants to start the server
read -p "🚀 Apakah Anda ingin langsung menjalankan server? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "🚀 Starting development server..."
    npm run dev
fi