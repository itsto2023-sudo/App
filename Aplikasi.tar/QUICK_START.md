# 🚀 Quick Start Guide - Instalasi Cepat

## ⚡ Instalasi 5 Menit

### 1️⃣ Clone & Install
```bash
# Clone project (atau copy folder)
git clone <repository-url> manajemen-aset-it
cd manajemen-aset-it

# Install dependencies
npm install
```

### 2️⃣ Setup Database
```bash
# Generate Prisma client
npx prisma generate

# Create database
npx prisma db push
```

### 3️⃣ Start App
```bash
# Jalankan development server
npm run dev
```

### 4️⃣ Buka Browser
🌐 **http://localhost:3000**

---

## 🎯 Demo Fitur (5 Menit)

### Homepage Dashboard
- ✅ 6 kategori aset dengan cards
- ✅ Statistik real-time
- ✅ Navigasi yang intuitif

### Tambah Aset Baru
1. Klik **"Kelola Radio HT"**
2. Klik **"Tambah Aset"**
3. Isi form:
   - Nama Aset: "Radio HT Baru"
   - Kategori: "Radio HT"
   - User: "John Doe"
   - NIK: "12345"
   - Department: "ICTs"
4. Klik **"Simpan"**

### Lihat Detail Aset
1. Klik icon **👁️** pada aset
2. Lihat informasi lengkap
3. Tambah riwayat penggunaan

### Filter & Search
1. Gunakan search bar untuk mencari
2. Filter berdasarkan status
3. Export data ke CSV

---

## 🔥 Tips & Tricks

### Keyboard Shortcuts
- **Ctrl/Cmd + K**: Quick search
- **Esc**: Close dialog
- **Enter**: Submit form

### Pro Tips
1. **Bulk Operations**: Select multiple assets untuk batch actions
2. **Quick Filters**: Use status badges untuk filter cepat
3. **Data Export**: Export ke CSV untuk reporting
4. **Responsive Design**: Works di mobile, tablet, desktop

---

## 🚨 Common Issues & Quick Fixes

### ❌ "Port 3000 already in use"
```bash
# Kill process
lsof -ti:3000 | xargs kill -9
# Atau gunakan port lain
npm run dev -- -p 3001
```

### ❌ "Prisma Client not found"
```bash
npx prisma generate
npm run dev
```

### ❌ "Database not found"
```bash
npx prisma db push
npm run dev
```

---

## 📱 Mobile Usage

### Responsive Features
- ✅ Touch-friendly buttons
- ✅ Swipe gestures untuk navigation
- ✅ Optimized tables untuk mobile
- ✅ Collapsible filters

### Mobile Navigation
1. **Home**: Dashboard dengan cards
2. **Assets**: List dengan horizontal scroll
3. **Detail**: Full-width information
4. **Actions**: Bottom action buttons

---

## 🎨 Customization Quick

### Ganti Colors
Edit `tailwind.config.ts`:
```typescript
theme: {
  extend: {
    colors: {
      primary: {
        50: '#eff6ff',
        500: '#3b82f6',
        900: '#1e3a8a',
      }
    }
  }
}
```

### Tambah Logo
1. Logo ke `public/logo.png`
2. Update di `src/app/layout.tsx`

### Custom Departments
Edit `src/app/assets/page.tsx`:
```typescript
const departmentOptions = [
  'Your Dept 1',
  'Your Dept 2',
  // ... tambah department lainnya
]
```

---

## 🚀 Production Deployment

### Build & Deploy
```bash
# Build untuk production
npm run build

# Start production server
npm start

# Atau deploy ke Vercel/Netlify
vercel --prod
```

### Environment Variables
```env
DATABASE_URL="file:./prod.db"
NEXTAUTH_SECRET="your-production-secret"
NEXTAUTH_URL="https://your-domain.com"
```

---

## 📞 Need Help?

### Resources
- 📖 **Full Documentation**: `TUTORIAL_PASANG.md`
- 🐛 **Issue Reporting**: GitHub Issues
- 💬 **Community**: Discord/Slack channel

### Quick Commands
```bash
# Check health
curl http://localhost:3000/api/health

# Seed sample data
curl http://localhost:3000/api/seed

# Check logs
tail -f dev.log
```

---

## 🎉 You're Ready!

**Sistem Manajemen Aset IT Anda sudah berjalan! 🚀**

### Next Steps:
1. 📊 **Explore Dashboard**: Lihat statistik aset
2. ➕ **Add Sample Data**: Tambah data testing
3. 👥 **Team Training**: Training untuk user
4. 🔧 **Customize**: Sesuaikan dengan kebutuhan
5. 📈 **Monitor**: Track performance dan usage

**Happy Asset Managing! 📱💼**