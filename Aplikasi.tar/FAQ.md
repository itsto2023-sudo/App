# ❓ Frequently Asked Questions (FAQ)

## 🚀 Installation & Setup

### Q: Apa saja yang dibutuhkan untuk instalasi?
**A:** Minimum requirements:
- Node.js 18 atau lebih tinggi
- npm atau yarn
- Git (opsional)
- 2GB RAM minimum
- 1GB disk space

### Q: Bagaimana cara install di Windows?
**A:** 
1. Install Node.js dari [nodejs.org](https://nodejs.org)
2. Install Git dari [git-scm.com](https://git-scm.com)
3. Buka Command Prompt atau PowerShell
4. Ikuti langkah instalasi di `TUTORIAL_PASANG.md`

### Q: Apakah bisa diinstall tanpa coding?
**A:** Ya! Gunakan setup script otomatis:
```bash
chmod +x setup.sh
./setup.sh
```

### Q: Port 3000 sudah digunakan, bagaimana?
**A:** Gunakan port lain:
```bash
npm run dev -- -p 3001
# Atau kill process yang menggunakan port 3000
lsof -ti:3000 | xargs kill -9
```

---

## 🗄️ Database

### Q: Database apa yang digunakan?
**A:** Default menggunakan SQLite (file-based). Bisa juga menggunakan PostgreSQL atau MySQL.

### Q: Bagaimana cara backup database?
**A:** 
```bash
# Backup SQLite
cp prisma/dev.db backup/dev-$(date +%Y%m%d).db

# Atau gunakan script backup
./backup.sh
```

### Q: Bagaimana cara migrasi ke PostgreSQL?
**A:** 
1. Install PostgreSQL
2. Update `DATABASE_URL` di `.env.local`
3. Update provider di `prisma/schema.prisma`
4. Run `npx prisma db push`

### Q: Data hilang setelah restart?
**A:** Pastikan file database ada di folder yang benar:
```bash
# Check database location
ls -la prisma/dev.db

# Pastikan tidak di .gitignore
echo "prisma/dev.db" >> .gitignore
```

---

## 🔐 Security & Authentication

### Q: Apakah sistem ini aman?
**A:** Ya, sistem memiliki:
- Input validation
- SQL injection prevention (Prisma ORM)
- XSS protection
- CSRF protection
- Secure headers

### Q: Bagaimana setup authentication?
**A:** Saat ini menggunakan NextAuth.js. Konfigurasi di:
- `.env.local` untuk secret key
- `src/app/api/auth/[...nextauth]/route.ts` untuk providers

### Q: Apakah bisa multi-user?
**A:** Ya, sistem support multi-user dengan role-based access control.

---

## 📱 Features & Functionality

### Q: Kategori aset apa saja yang didukung?
**A:** 6 kategori:
- Radio HT
- Radio RIG  
- Laptop
- Printer
- Komputer
- Lainnya

### Q: Apa bedanya Radio RIG dengan kategori lain?
**A:** Radio RIG memiliki field khusus:
- Unit Code
- Nama Unit
- Jenis Unit
- UR (Unit Reference)
- PO (Purchase Order)

Kategori lain memiliki field:
- User Name
- NIK
- Department

### Q: Department apa saja yang tersedia?
**A:** 10 department:
- ICTs, HGAs, LOGs, ENGs, SHEs, PDCs, PLTs, FINs, TCNs, SKUs

### Q: Bisa tambah department baru?
**A:** Ya, edit file `src/app/assets/page.tsx`:
```typescript
const departmentOptions = [
  'ICTs', 'HGAs', 'LOGs', 'ENGs', 'SHEs',
  'PDCs', 'PLTs', 'FINs', 'TCNs', 'SKUs',
  'DEPT_BARU' // Tambah department baru
]
```

---

## 🎨 Customization

### Q: Bagaimana ganti warna tema?
**A:** Edit `tailwind.config.ts`:
```typescript
theme: {
  extend: {
    colors: {
      primary: {
        50: '#eff6ff',
        500: '#3b82f6',
        900: '#1e3a8a',
      }
    }
  }
}
```

### Q: Bagaimana tambah logo perusahaan?
**A:** 
1. Logo ke `public/logo.png`
2. Update di `src/app/layout.tsx`
3. Atau gunakan Next.js Image component

### Q: Bisa custom field?
**A:** Ya, edit:
1. `prisma/schema.prisma` untuk database
2. API routes untuk backend
3. Components untuk frontend

---

## 🐛 Troubleshooting

### Q: Error "Prisma Client not found"
**A:** 
```bash
npx prisma generate
npm install
```

### Q: Error "Cannot resolve module"
**A:** 
```bash
rm -rf node_modules package-lock.json
npm install
```

### Q: Build gagal di production?
**A:** 
```bash
# Clear cache
rm -rf .next
npm run build
```

### Q: Loading sangat lambat?
**A:** 
- Check database size
- Add indexes ke database
- Enable caching
- Check network connection

### Q: Mobile responsive tidak berjalan?
**A:** 
- Check viewport meta tag
- Test di browser mobile dev tools
- Check Tailwind responsive classes

---

## 📊 Performance & Scaling

### Q: Berapa banyak aset yang bisa ditangani?
**A:** SQLite: ~10,000 records optimal
PostgreSQL: 100,000+ records

### Q: Bagaimana optimasi performance?
**A:** 
- Add database indexes
- Enable caching
- Use pagination
- Optimize images
- Minimize API calls

### Q: Bisa handle multiple users?
**A:** Ya, dengan proper scaling:
- Use connection pooling
- Implement rate limiting
- Add caching layer
- Use load balancer

---

## 🔧 Maintenance

### Q: Bagaimana update aplikasi?
**A:** 
```bash
# Pull latest changes
git pull origin main

# Update dependencies
npm update

# Rebuild
npm run build

# Restart server
pm2 restart manajemen-aset-it
```

### Q: Bagaimana monitoring aplikasi?
**A:** 
- Use PM2 monitoring: `pm2 monit`
- Check logs: `pm2 logs`
- Health check: `curl /api/health`
- Use external monitoring tools

### Q: Schedule maintenance?
**A:** 
```bash
# Backup otomatis dengan cron
0 2 * * * /path/to/backup.sh

# Restart otomatis
0 3 * * 0 pm2 restart manajemen-aset-it
```

---

## 🌐 Deployment

### Q: Bagaimana deploy ke Vercel?
**A:** 
1. Install Vercel CLI
2. Run `vercel`
3. Set environment variables
4. Deploy dengan `vercel --prod`

### Q: Bagaimana deploy ke VPS?
**A:** Ikuti guide di `DEPLOYMENT.md`:
- Setup server
- Install dependencies
- Configure Nginx
- Setup SSL
- Configure PM2

### Q: Apakah perlu VPS?
**A:** Tidak, bisa deploy ke:
- Vercel (recommended)
- Netlify
- Railway
- Heroku
- VPS (full control)

---

## 💾 Data Management

### Q: Bagaimana export data?
**A:** 
- Built-in CSV export di assets page
- Atau query database langsung
- Atau gunakan Prisma Studio

### Q: Bagaimana import data dari Excel?
**A:** 
1. Convert Excel ke CSV
2. Parse CSV di backend
3. Validate data
4. Insert ke database

### Q: Bagaimana restore dari backup?
**A:** 
```bash
# Stop application
pm2 stop manajemen-aset-it

# Restore database
cp backup/dev-20240101.db prisma/dev.db

# Start application
pm2 start manajemen-aset-it
```

---

## 🔌 API & Integration

### Q: Apakah ada API documentation?
**A:** Ya, check endpoints di `src/app/api/`:
- `/api/assets` - CRUD assets
- `/api/assets/[id]` - Detail asset
- `/api/assets/[id]/history` - Asset history
- `/api/health` - Health check

### Q: Bagaimana integrate dengan sistem lain?
**A:** 
- Use REST API endpoints
- Implement webhooks
- Use middleware untuk authentication
- Follow REST conventions

### Q: Bisa tambah custom API?
**A:** Ya, buat file baru di `src/app/api/`:
```typescript
// src/app/api/custom/route.ts
export async function GET() {
  return Response.json({ message: 'Custom API' })
}
```

---

## 📱 Mobile & PWA

### Q: Apakah ada mobile app?
**A:** Saat ini web-based responsive. Bisa convert ke PWA:
1. Add manifest.json
2. Service worker
3. Install prompts

### Q: Bagaimana akses di mobile?
**A:** 
- Browser responsive design
- Add to home screen
- Works offline dengan PWA
- Touch-friendly interface

---

## 🆘 Getting Help

### Q: Dimana bisa dapat bantuan?
**A:** 
- 📖 Documentation: `TUTORIAL_PASANG.md`
- 🚀 Quick Start: `QUICK_START.md`
- 🚀 Deployment: `DEPLOYMENT.md`
- 🐛 Issues: GitHub repository
- 💬 Community: Discord/Slack

### Q: Bagaimana report bug?
**A:** 
1. Check existing issues
2. Create new issue dengan:
   - Environment details
   - Steps to reproduce
   - Expected vs actual behavior
   - Screenshots jika perlu

### Q: Bagaimana request feature?
**A:** 
1. Check existing feature requests
2. Create new issue dengan label "enhancement"
3. Describe use case
4. Provide mockups jika perlu

---

## 💡 Tips & Tricks

### Q: Tips untuk penggunaan efisien?
**A:** 
- Use keyboard shortcuts
- Bookmark frequently accessed pages
- Use filters untuk large datasets
- Regular backup schedule
- Monitor application health

### Q: Best practices untuk data entry?
**A:** 
- Consistent naming conventions
- Complete all required fields
- Regular data validation
- Use standardized formats
- Document custom fields

### Q: How to train team?
**A:** 
- Start dengan demo data
- Provide user manual
- Conduct hands-on training
- Create video tutorials
- Provide cheat sheet

---

## 🔮 Future Development

### Q: Roadmap untuk fitur baru?
**A:** 
- Image upload support
- Advanced analytics
- Mobile app
- Barcode scanning
- Multi-language support
- Advanced reporting

### Q: Bagaimana contribute ke project?
**A:** 
1. Fork repository
2. Create feature branch
3. Make changes
4. Add tests
5. Submit pull request

### Q: Bagaimana stay updated?
**A:** 
- Watch GitHub repository
- Subscribe to releases
- Join community channels
- Follow development blog

---

## 🎉 Quick FAQ Summary

| Category | Common Issue | Quick Fix |
|----------|--------------|-----------|
| **Setup** | Port 3000 used | Use port 3001 or kill process |
| **Database** | Connection error | Check file permissions |
| **Build** | Build fails | Clear `.next` cache |
| **Performance** | Slow loading | Add indexes, enable caching |
| **Mobile** | Not responsive | Check viewport meta tag |
| **Security** | Authentication issues | Check environment variables |

---

**🚀 Still need help?** 

- 📧 Email: support@company.com
- 💬 Discord: [Join Community](https://discord.gg/invite)
- 📖 Full Documentation: [Check Docs](./TUTORIAL_PASANG.md)
- 🐛 Report Issues: [GitHub Issues](https://github.com/your-repo/issues)

**We're here to help you succeed! 🎯**