'use client'

import { useState, useEffect, useMemo } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Plus, Edit, Trash2, Search, Image as ImageIcon, Eye, Filter, Download, ChevronUp, ChevronDown, BarChart3 } from 'lucide-react'
import Link from 'next/link'

interface Asset {
  id: string
  nama_aset: string
  kategori: string
  merk?: string
  model?: string
  serial_number?: string
  no_asset_acc?: string
  status: string
  catatan?: string
  gambar_url?: string
  createdAt: string
  updatedAt: string
  assetRadio?: {
    id: string
    unit_code?: string
    nama_unit?: string
    jenis_unit?: string
    ur?: string
    po?: string
  }
  assetGeneral?: {
    id: string
    user_name?: string
    nik?: string
    department?: string
  }
}

const kategoriOptions = [
  'Radio HT',
  'Radio RIG', 
  'Laptop',
  'Printer',
  'Komputer',
  'Lainnya'
]

const statusOptions = ['Baik', 'Rusak', 'Hilang', 'Maintenance', 'Mutasi']

const jenisUnitOptions = [
  'HDKM785', 'HDSY95', 'R100', 'R60', 'A40F', 'A60H', 'ADT CAT', 'DWSN80',
  'EXCA LIEBHER', 'EXCA PC2000', 'EXCA HITACHI', 'EXCA VOLVO', 'EXCA KOBELCO',
  'EXCA CAT', 'EXCA SANY', 'EXCA AMPHIBI', 'GREADER', 'BULDOZER', 'WHEEL LOADER',
  'COMPAC', 'DUTRO', 'LOWBOY', 'LONG ARM', 'LV', 'WATER TRUCK', 'FUEL TRUCK',
  'WASHING TRUCK', 'BUS-ELF', 'LUBE TRUCK', 'DT HYUNDAI', 'DT HINO', 'BUILD',
  'CRANE TRUCK', 'DT', 'IZUZU', 'DT RENAULT', 'STOCK', 'HILANG', 'RUSAK', 'MUTASI'
]

const departmentOptions = [
  'ICTs',
  'HGAs', 
  'LOGs',
  'ENGs',
  'SHEs',
  'PDCs',
  'PLTs',
  'FINs',
  'TCNs',
  'SKUs'
]

export default function AssetsPage() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const kategoriFilter = searchParams.get('kategori') || ''
  
  const [assets, setAssets] = useState<Asset[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [sortBy, setSortBy] = useState<'nama_aset' | 'createdAt' | 'status'>('nama_aset')
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc')
  const [currentPage, setCurrentPage] = useState(1)
  const [itemsPerPage, setItemsPerPage] = useState(10)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null)
  const [showFilters, setShowFilters] = useState(false)
  const [formData, setFormData] = useState({
    nama_aset: '',
    kategori: kategoriFilter || '',
    merk: '',
    model: '',
    serial_number: '',
    no_asset_acc: '',
    status: 'Baik',
    catatan: '',
    unit_code: '',
    nama_unit: '',
    jenis_unit: '',
    ur: '',
    po: '',
    user_name: '',
    nik: '',
    department: ''
  })

  const fetchAssets = async () => {
    try {
      const response = await fetch('/api/assets')
      if (response.ok) {
        const data = await response.json()
        setAssets(data)
      }
    } catch (error) {
      console.error('Error fetching assets:', error)
    } finally {
      setLoading(false)
    }
  }

  const filteredAndSortedAssets = useMemo(() => {
    let filtered = assets
    
    // Filter by kategori
    if (kategoriFilter) {
      filtered = filtered.filter((asset: Asset) => asset.kategori === kategoriFilter)
    }
    
    // Filter by status
    if (statusFilter) {
      filtered = filtered.filter((asset: Asset) => asset.status === statusFilter)
    }
    
    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter((asset: Asset) =>
        asset.nama_aset.toLowerCase().includes(searchTerm.toLowerCase()) ||
        asset.serial_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        asset.no_asset_acc?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        asset.merk?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        asset.model?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }
    
    // Sort
    filtered.sort((a: Asset, b: Asset) => {
      let aValue = a[sortBy]
      let bValue = b[sortBy]
      
      if (sortBy === 'createdAt') {
        aValue = new Date(aValue).getTime()
        bValue = new Date(bValue).getTime()
      }
      
      if (aValue < bValue) return sortOrder === 'asc' ? -1 : 1
      if (aValue > bValue) return sortOrder === 'asc' ? 1 : -1
      return 0
    })
    
    return filtered
  }, [assets, kategoriFilter, statusFilter, searchTerm, sortBy, sortOrder])
  
  // Pagination
  const totalPages = Math.ceil(filteredAndSortedAssets.length / itemsPerPage)
  const paginatedAssets = filteredAndSortedAssets.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  )
  
  // Statistics
  const statistics = useMemo(() => {
    const total = assets.length
    const byStatus = statusOptions.reduce((acc, status) => {
      acc[status] = assets.filter(asset => asset.status === status).length
      return acc
    }, {} as Record<string, number>)
    const byKategori = kategoriOptions.reduce((acc, kategori) => {
      acc[kategori] = assets.filter(asset => asset.kategori === kategori).length
      return acc
    }, {} as Record<string, number>)
    
    return { total, byStatus, byKategori }
  }, [assets])

  useEffect(() => {
    fetchAssets()
  }, [])
  
  useEffect(() => {
    setCurrentPage(1)
  }, [kategoriFilter, statusFilter, searchTerm])

  const handleCreateAsset = async () => {
    try {
      const response = await fetch('/api/assets', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })
      
      if (response.ok) {
        setIsCreateDialogOpen(false)
        setFormData({
          nama_aset: '',
          kategori: kategoriFilter || '',
          merk: '',
          model: '',
          serial_number: '',
          no_asset_acc: '',
          status: 'Baik',
          catatan: '',
          unit_code: '',
          nama_unit: '',
          jenis_unit: '',
          ur: '',
          po: '',
          user_name: '',
          nik: '',
          department: ''
        })
        fetchAssets()
      }
    } catch (error) {
      console.error('Error creating asset:', error)
    }
  }

  const handleUpdateAsset = async () => {
    if (!selectedAsset) return
    
    try {
      const response = await fetch(`/api/assets/${selectedAsset.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })
      
      if (response.ok) {
        setIsEditDialogOpen(false)
        setSelectedAsset(null)
        fetchAssets()
      }
    } catch (error) {
      console.error('Error updating asset:', error)
    }
  }

  const handleDeleteAsset = async (id: string) => {
    if (!confirm('Apakah Anda yakin ingin menghapus aset ini?')) return
    
    try {
      const response = await fetch(`/api/assets/${id}`, {
        method: 'DELETE',
      })
      
      if (response.ok) {
        fetchAssets()
      }
    } catch (error) {
      console.error('Error deleting asset:', error)
    }
  }

  const openEditDialog = (asset: Asset) => {
    setSelectedAsset(asset)
    setFormData({
      nama_aset: asset.nama_aset,
      kategori: asset.kategori,
      merk: asset.merk || '',
      model: asset.model || '',
      serial_number: asset.serial_number || '',
      no_asset_acc: asset.no_asset_acc || '',
      status: asset.status,
      catatan: asset.catatan || '',
      unit_code: asset.assetRadio?.unit_code || '',
      nama_unit: asset.assetRadio?.nama_unit || '',
      jenis_unit: asset.assetRadio?.jenis_unit || '',
      ur: asset.assetRadio?.ur || '',
      po: asset.assetRadio?.po || '',
      user_name: asset.assetGeneral?.user_name || '',
      nik: asset.assetGeneral?.nik || '',
      department: asset.assetGeneral?.department || ''
    })
    setIsEditDialogOpen(true)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Baik': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'
      case 'Rusak': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'
      case 'Hilang': return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300'
      case 'Maintenance': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300'
      case 'Mutasi': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300'
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300'
    }
  }
  
  const handleSort = (column: 'nama_aset' | 'createdAt' | 'status') => {
    if (sortBy === column) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')
    } else {
      setSortBy(column)
      setSortOrder('asc')
    }
  }
  
  const exportToCSV = () => {
    const headers = ['Nama Aset', 'Kategori', 'Merk', 'Model', 'Serial Number', 'No Asset ACC', 'Status', 'Catatan']
    const csvContent = [
      headers.join(','),
      ...filteredAndSortedAssets.map(asset => [
        asset.nama_aset,
        asset.kategori,
        asset.merk || '',
        asset.model || '',
        asset.serial_number || '',
        asset.no_asset_acc || '',
        asset.status,
        asset.catatan || ''
      ].map(field => `"${field}"`).join(','))
    ].join('\n')
    
    const blob = new Blob([csvContent], { type: 'text/csv' })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `assets-${new Date().toISOString().split('T')[0]}.csv`
    a.click()
    window.URL.revokeObjectURL(url)
  }
  
  const clearFilters = () => {
    setStatusFilter('')
    setSearchTerm('')
    router.push('/assets')
  }

  return (
    <div className="bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
      <div className="max-w-7xl mx-auto p-4 md:p-8">
        <div className="mb-8">
          {/* Statistics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Aset</p>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">{statistics.total}</p>
                  </div>
                  <BarChart3 className="h-8 w-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Aset Baik</p>
                    <p className="text-2xl font-bold text-green-600">{statistics.byStatus.Baik || 0}</p>
                  </div>
                  <div className="h-8 w-8 bg-green-100 rounded-full flex items-center justify-center">
                    <div className="h-4 w-4 bg-green-500 rounded-full"></div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Butuh Perhatian</p>
                    <p className="text-2xl font-bold text-orange-600">
                      {(statistics.byStatus.Rusak || 0) + (statistics.byStatus.Maintenance || 0)}
                    </p>
                  </div>
                  <div className="h-8 w-8 bg-orange-100 rounded-full flex items-center justify-center">
                    <div className="h-4 w-4 bg-orange-500 rounded-full"></div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Filter Aktif</p>
                    <p className="text-2xl font-bold text-blue-600">
                      {[kategoriFilter, statusFilter, searchTerm].filter(Boolean).length}
                    </p>
                  </div>
                  <Filter className="h-8 w-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
                {kategoriFilter ? `Daftar Aset - ${kategoriFilter}` : 'Semua Aset'}
              </h1>
              <p className="text-gray-600 dark:text-gray-300">
                Kelola aset perusahaan • {filteredAndSortedAssets.length} dari {statistics.total} aset
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                onClick={exportToCSV}
                className="flex items-center gap-2"
              >
                <Download className="h-4 w-4" />
                Export CSV
              </Button>
              <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Tambah Aset
                  </Button>
                </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Tambah Aset Baru</DialogTitle>
                  <DialogDescription>
                    Tambahkan aset baru ke dalam sistem
                  </DialogDescription>
                </DialogHeader>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="nama_aset">Nama Aset</Label>
                    <Input
                      id="nama_aset"
                      value={formData.nama_aset}
                      onChange={(e) => setFormData({ ...formData, nama_aset: e.target.value })}
                      placeholder="Masukkan nama aset"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="kategori">Kategori</Label>
                    <Select value={formData.kategori} onValueChange={(value) => setFormData({ ...formData, kategori: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih kategori" />
                      </SelectTrigger>
                      <SelectContent>
                        {kategoriOptions.map((kategori) => (
                          <SelectItem key={kategori} value={kategori}>{kategori}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="merk">Merk</Label>
                    <Input
                      id="merk"
                      value={formData.merk}
                      onChange={(e) => setFormData({ ...formData, merk: e.target.value })}
                      placeholder="Masukkan merk"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="model">Model</Label>
                    <Input
                      id="model"
                      value={formData.model}
                      onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                      placeholder="Masukkan model"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="serial_number">Serial Number</Label>
                    <Input
                      id="serial_number"
                      value={formData.serial_number}
                      onChange={(e) => setFormData({ ...formData, serial_number: e.target.value })}
                      placeholder="Masukkan serial number"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="no_asset_acc">No Asset ACC</Label>
                    <Input
                      id="no_asset_acc"
                      value={formData.no_asset_acc}
                      onChange={(e) => setFormData({ ...formData, no_asset_acc: e.target.value })}
                      placeholder="Masukkan no asset ACC"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="status">Status</Label>
                    <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih status" />
                      </SelectTrigger>
                      <SelectContent>
                        {statusOptions.map((status) => (
                          <SelectItem key={status} value={status}>{status}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {formData.kategori === 'Radio RIG' && (
                    <>
                      <div className="space-y-2">
                        <Label htmlFor="unit_code">Unit Code</Label>
                        <Input
                          id="unit_code"
                          value={formData.unit_code}
                          onChange={(e) => setFormData({ ...formData, unit_code: e.target.value })}
                          placeholder="Masukkan unit code"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="nama_unit">Nama Unit</Label>
                        <Input
                          id="nama_unit"
                          value={formData.nama_unit}
                          onChange={(e) => setFormData({ ...formData, nama_unit: e.target.value })}
                          placeholder="Masukkan nama unit"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="jenis_unit">Jenis Unit</Label>
                        <Select value={formData.jenis_unit} onValueChange={(value) => setFormData({ ...formData, jenis_unit: value })}>
                          <SelectTrigger>
                            <SelectValue placeholder="Pilih jenis unit" />
                          </SelectTrigger>
                          <SelectContent>
                            {jenisUnitOptions.map((jenis) => (
                              <SelectItem key={jenis} value={jenis}>{jenis}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="ur">UR</Label>
                        <Input
                          id="ur"
                          value={formData.ur}
                          onChange={(e) => setFormData({ ...formData, ur: e.target.value })}
                          placeholder="Masukkan UR"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="po">PO</Label>
                        <Input
                          id="po"
                          value={formData.po}
                          onChange={(e) => setFormData({ ...formData, po: e.target.value })}
                          placeholder="Masukkan PO"
                        />
                      </div>
                    </>
                  )}
                  
                  {/* Fields for Radio HT, Printer, Laptop, Komputer, dan Lainnya */}
                  {['Radio HT', 'Printer', 'Laptop', 'Komputer', 'Lainnya'].includes(formData.kategori) && (
                    <>
                      <div className="space-y-2">
                        <Label htmlFor="user_name">User</Label>
                        <Input
                          id="user_name"
                          value={formData.user_name}
                          onChange={(e) => setFormData({ ...formData, user_name: e.target.value })}
                          placeholder="Masukkan nama user"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="nik">NIK</Label>
                        <Input
                          id="nik"
                          value={formData.nik}
                          onChange={(e) => setFormData({ ...formData, nik: e.target.value })}
                          placeholder="Masukkan NIK"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="department">Department</Label>
                        <Select value={formData.department} onValueChange={(value) => setFormData({ ...formData, department: value })}>
                          <SelectTrigger>
                            <SelectValue placeholder="Pilih department" />
                          </SelectTrigger>
                          <SelectContent>
                            {departmentOptions.map((dept) => (
                              <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </>
                  )}
                  
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="catatan">Catatan</Label>
                    <Textarea
                      id="catatan"
                      value={formData.catatan}
                      onChange={(e) => setFormData({ ...formData, catatan: e.target.value })}
                      placeholder="Masukkan catatan"
                      rows={3}
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-2 mt-6">
                  <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                    Batal
                  </Button>
                  <Button onClick={handleCreateAsset}>
                    Simpan
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
          
          <div className="flex flex-col lg:flex-row items-start lg:items-center gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Cari aset..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center gap-2"
              >
                <Filter className="h-4 w-4" />
                Filter
                {(statusFilter || kategoriFilter) && (
                  <Badge variant="secondary" className="ml-1">
                    {[statusFilter, kategoriFilter].filter(Boolean).length}
                  </Badge>
                )}
              </Button>
              
              {(statusFilter || kategoriFilter || searchTerm) && (
                <Button
                  variant="ghost"
                  onClick={clearFilters}
                  className="text-gray-500 hover:text-gray-700"
                >
                  Clear
                </Button>
              )}
            </div>
          </div>
          
          {/* Advanced Filters */}
          {showFilters && (
            <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-gray-200 dark:border-gray-700 mt-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Filter Status</Label>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger>
                      <SelectValue placeholder="Semua status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Semua status</SelectItem>
                      {statusOptions.map((status) => (
                        <SelectItem key={status} value={status}>{status}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>Items per halaman</Label>
                  <Select value={itemsPerPage.toString()} onValueChange={(value) => setItemsPerPage(Number(value))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">5</SelectItem>
                      <SelectItem value="10">10</SelectItem>
                      <SelectItem value="25">25</SelectItem>
                      <SelectItem value="50">50</SelectItem>
                      <SelectItem value="100">100</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>Urutkan</Label>
                  <Select value={`${sortBy}-${sortOrder}`} onValueChange={(value) => {
                    const [field, order] = value.split('-')
                    setSortBy(field as 'nama_aset' | 'createdAt' | 'status')
                    setSortOrder(order as 'asc' | 'desc')
                  }}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="nama_aset-asc">Nama A-Z</SelectItem>
                      <SelectItem value="nama_aset-desc">Nama Z-A</SelectItem>
                      <SelectItem value="createdAt-desc">Terbaru</SelectItem>
                      <SelectItem value="createdAt-asc">Terlama</SelectItem>
                      <SelectItem value="status-asc">Status A-Z</SelectItem>
                      <SelectItem value="status-desc">Status Z-A</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

        <Card>
          <CardHeader>
            <CardTitle>Daftar Aset</CardTitle>
            <CardDescription>
              Menampilkan {paginatedAssets.length} dari {filteredAndSortedAssets.length} aset 
              {filteredAndSortedAssets.length !== statistics.total && ` (dari total ${statistics.total} aset)`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8">Memuat data...</div>
            ) : paginatedAssets.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                {filteredAndSortedAssets.length === 0 ? 'Tidak ada aset yang ditemukan' : 'Tidak ada aset pada halaman ini'}
              </div>
            ) : (
              <>
                <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleSort('nama_aset')}
                          className="font-semibold hover:bg-gray-100 dark:hover:bg-gray-800 p-1 h-auto"
                        >
                          Nama Aset
                          {sortBy === 'nama_aset' && (
                            sortOrder === 'asc' ? <ChevronUp className="h-4 w-4 ml-1" /> : <ChevronDown className="h-4 w-4 ml-1" />
                          )}
                        </Button>
                      </TableHead>
                      <TableHead>Kategori</TableHead>
                      <TableHead>Merk/Model</TableHead>
                      <TableHead>Serial Number</TableHead>
                      <TableHead>No Asset ACC</TableHead>
                      <TableHead>User/NIK/Department</TableHead>
                      <TableHead>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleSort('status')}
                          className="font-semibold hover:bg-gray-100 dark:hover:bg-gray-800 p-1 h-auto"
                        >
                          Status
                          {sortBy === 'status' && (
                            sortOrder === 'asc' ? <ChevronUp className="h-4 w-4 ml-1" /> : <ChevronDown className="h-4 w-4 ml-1" />
                          )}
                        </Button>
                      </TableHead>
                      <TableHead className="text-center">Aksi</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedAssets.map((asset) => (
                      <TableRow key={asset.id}>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            {asset.gambar_url ? (
                              <div className="w-8 h-8 rounded bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                                <ImageIcon className="h-4 w-4 text-gray-500" />
                              </div>
                            ) : null}
                            {asset.nama_aset}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary">{asset.kategori}</Badge>
                        </TableCell>
                        <TableCell>
                          {asset.merk && asset.model ? `${asset.merk} ${asset.model}` : asset.merk || asset.model || '-'}
                        </TableCell>
                        <TableCell>{asset.serial_number || '-'}</TableCell>
                        <TableCell>{asset.no_asset_acc || '-'}</TableCell>
                        <TableCell>
                          {asset.assetGeneral ? (
                            <div className="text-sm">
                              <div className="font-medium">{asset.assetGeneral.user_name || '-'}</div>
                              <div className="text-gray-500">{asset.assetGeneral.nik || '-'}</div>
                              <div className="text-gray-500">{asset.assetGeneral.department || '-'}</div>
                            </div>
                          ) : asset.assetRadio ? (
                            <div className="text-sm">
                              <div className="font-medium">{asset.assetRadio.nama_unit || '-'}</div>
                              <div className="text-gray-500">{asset.assetRadio.unit_code || '-'}</div>
                              <div className="text-gray-500">{asset.assetRadio.jenis_unit || '-'}</div>
                            </div>
                          ) : (
                            '-'
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(asset.status)}>
                            {asset.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center justify-center gap-1">
                            <Link href={`/assets/${asset.id}`}>
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="text-blue-600 hover:text-blue-700 hover:bg-blue-50 dark:hover:bg-blue-950 transition-all duration-200"
                                title="Lihat Detail"
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                            </Link>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => openEditDialog(asset)}
                              className="text-amber-600 hover:text-amber-700 hover:bg-amber-50 dark:hover:bg-amber-950 transition-all duration-200"
                              title="Edit Aset"
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteAsset(asset.id)}
                              className="text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-950 transition-all duration-200"
                              title="Hapus Aset"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              
              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between mt-4">
                  <div className="text-sm text-gray-600 dark:text-gray-400">
                    Menampilkan {((currentPage - 1) * itemsPerPage) + 1} hingga {Math.min(currentPage * itemsPerPage, filteredAndSortedAssets.length)} dari {filteredAndSortedAssets.length} aset
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                      disabled={currentPage === 1}
                    >
                      Previous
                    </Button>
                    
                    <div className="flex items-center gap-1">
                      {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                        let pageNum
                        if (totalPages <= 5) {
                          pageNum = i + 1
                        } else if (currentPage <= 3) {
                          pageNum = i + 1
                        } else if (currentPage >= totalPages - 2) {
                          pageNum = totalPages - 4 + i
                        } else {
                          pageNum = currentPage - 2 + i
                        }
                        
                        return (
                          <Button
                            key={pageNum}
                            variant={currentPage === pageNum ? "default" : "outline"}
                            size="sm"
                            onClick={() => setCurrentPage(pageNum)}
                            className="w-8 h-8 p-0"
                          >
                            {pageNum}
                          </Button>
                        )
                      })}
                    </div>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                      disabled={currentPage === totalPages}
                    >
                      Next
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
          </CardContent>
        </Card>

        {/* Edit Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit Aset</DialogTitle>
              <DialogDescription>
                Perbarui informasi aset
              </DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit_nama_aset">Nama Aset</Label>
                <Input
                  id="edit_nama_aset"
                  value={formData.nama_aset}
                  onChange={(e) => setFormData({ ...formData, nama_aset: e.target.value })}
                  placeholder="Masukkan nama aset"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit_kategori">Kategori</Label>
                <Select value={formData.kategori} onValueChange={(value) => setFormData({ ...formData, kategori: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih kategori" />
                  </SelectTrigger>
                  <SelectContent>
                    {kategoriOptions.map((kategori) => (
                      <SelectItem key={kategori} value={kategori}>{kategori}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit_merk">Merk</Label>
                <Input
                  id="edit_merk"
                  value={formData.merk}
                  onChange={(e) => setFormData({ ...formData, merk: e.target.value })}
                  placeholder="Masukkan merk"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit_model">Model</Label>
                <Input
                  id="edit_model"
                  value={formData.model}
                  onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                  placeholder="Masukkan model"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit_serial_number">Serial Number</Label>
                <Input
                  id="edit_serial_number"
                  value={formData.serial_number}
                  onChange={(e) => setFormData({ ...formData, serial_number: e.target.value })}
                  placeholder="Masukkan serial number"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit_no_asset_acc">No Asset ACC</Label>
                <Input
                  id="edit_no_asset_acc"
                  value={formData.no_asset_acc}
                  onChange={(e) => setFormData({ ...formData, no_asset_acc: e.target.value })}
                  placeholder="Masukkan no asset ACC"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit_status">Status</Label>
                <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih status" />
                  </SelectTrigger>
                  <SelectContent>
                    {statusOptions.map((status) => (
                      <SelectItem key={status} value={status}>{status}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              {formData.kategori === 'Radio RIG' && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="edit_unit_code">Unit Code</Label>
                    <Input
                      id="edit_unit_code"
                      value={formData.unit_code}
                      onChange={(e) => setFormData({ ...formData, unit_code: e.target.value })}
                      placeholder="Masukkan unit code"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit_nama_unit">Nama Unit</Label>
                    <Input
                      id="edit_nama_unit"
                      value={formData.nama_unit}
                      onChange={(e) => setFormData({ ...formData, nama_unit: e.target.value })}
                      placeholder="Masukkan nama unit"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit_jenis_unit">Jenis Unit</Label>
                    <Select value={formData.jenis_unit} onValueChange={(value) => setFormData({ ...formData, jenis_unit: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih jenis unit" />
                      </SelectTrigger>
                      <SelectContent>
                        {jenisUnitOptions.map((jenis) => (
                          <SelectItem key={jenis} value={jenis}>{jenis}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit_ur">UR</Label>
                    <Input
                      id="edit_ur"
                      value={formData.ur}
                      onChange={(e) => setFormData({ ...formData, ur: e.target.value })}
                      placeholder="Masukkan UR"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit_po">PO</Label>
                    <Input
                      id="edit_po"
                      value={formData.po}
                      onChange={(e) => setFormData({ ...formData, po: e.target.value })}
                      placeholder="Masukkan PO"
                    />
                  </div>
                </>
              )}
              
              {/* Fields for Radio HT, Printer, Laptop, Komputer, dan Lainnya */}
              {['Radio HT', 'Printer', 'Laptop', 'Komputer', 'Lainnya'].includes(formData.kategori) && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="edit_user_name">User</Label>
                    <Input
                      id="edit_user_name"
                      value={formData.user_name}
                      onChange={(e) => setFormData({ ...formData, user_name: e.target.value })}
                      placeholder="Masukkan nama user"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit_nik">NIK</Label>
                    <Input
                      id="edit_nik"
                      value={formData.nik}
                      onChange={(e) => setFormData({ ...formData, nik: e.target.value })}
                      placeholder="Masukkan NIK"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit_department">Department</Label>
                    <Select value={formData.department} onValueChange={(value) => setFormData({ ...formData, department: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih department" />
                      </SelectTrigger>
                      <SelectContent>
                        {departmentOptions.map((dept) => (
                          <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </>
              )}
              
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="edit_catatan">Catatan</Label>
                <Textarea
                  id="edit_catatan"
                  value={formData.catatan}
                  onChange={(e) => setFormData({ ...formData, catatan: e.target.value })}
                  placeholder="Masukkan catatan"
                  rows={3}
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-6">
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                Batal
              </Button>
              <Button onClick={handleUpdateAsset}>
                Update
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}