'use client'

import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Plus, Clock, User, Calendar, Image as ImageIcon, Edit } from 'lucide-react'
import Link from 'next/link'

interface Asset {
  id: string
  nama_aset: string
  kategori: string
  merk?: string
  model?: string
  serial_number?: string
  no_asset_acc?: string
  status: string
  catatan?: string
  gambar_url?: string
  createdAt: string
  updatedAt: string
  user: {
    id: string
    name: string
    email: string
  }
  assetRadio?: {
    id: string
    unit_code?: string
    nama_unit?: string
    jenis_unit?: string
    ur?: string
    po?: string
  }
  assetGeneral?: {
    id: string
    user_name?: string
    nik?: string
    department?: string
  }
  assetHistories: AssetHistory[]
}

interface AssetHistory {
  id: string
  assetId: string
  userId: string
  pengguna?: string
  status?: string
  catatan?: string
  tanggal: string
  user: {
    id: string
    name: string
    email: string
  }
}

const statusOptions = ['Baik', 'Rusak', 'Hilang', 'Maintenance', 'Mutasi']

export default function AssetDetailPage() {
  const params = useParams()
  const router = useRouter()
  const assetId = params.id as string
  
  const [asset, setAsset] = useState<Asset | null>(null)
  const [loading, setLoading] = useState(true)
  const [isHistoryDialogOpen, setIsHistoryDialogOpen] = useState(false)
  const [historyFormData, setHistoryFormData] = useState({
    pengguna: '',
    status: '',
    catatan: ''
  })

  const fetchAsset = async () => {
    try {
      const response = await fetch(`/api/assets/${assetId}`)
      if (response.ok) {
        const data = await response.json()
        setAsset(data)
      } else {
        console.error('Asset not found')
        router.push('/assets')
      }
    } catch (error) {
      console.error('Error fetching asset:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (assetId) {
      fetchAsset()
    }
  }, [assetId])

  const handleAddHistory = async () => {
    try {
      const response = await fetch(`/api/assets/${assetId}/history`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(historyFormData),
      })
      
      if (response.ok) {
        setIsHistoryDialogOpen(false)
        setHistoryFormData({
          pengguna: '',
          status: '',
          catatan: ''
        })
        fetchAsset()
      }
    } catch (error) {
      console.error('Error adding history:', error)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Baik': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'
      case 'Rusak': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'
      case 'Hilang': return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300'
      case 'Maintenance': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300'
      case 'Mutasi': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300'
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300'
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  if (loading) {
    return (
      <div className="bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
        <div className="max-w-7xl mx-auto p-4 md:p-8">
          <div className="text-center py-8">Memuat data aset...</div>
        </div>
      </div>
    )
  }

  if (!asset) {
    return (
      <div className="bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
        <div className="max-w-7xl mx-auto p-4 md:p-8">
          <div className="text-center py-8">Aset tidak ditemukan</div>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
      <div className="max-w-7xl mx-auto p-4 md:p-8">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
                Detail Aset
              </h1>
              <p className="text-gray-600 dark:text-gray-300">
                Informasi lengkap dan riwayat aset
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Asset Information */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-2xl">{asset.nama_aset}</CardTitle>
                    <CardDescription className="flex items-center gap-2 mt-2">
                      <Badge variant="secondary">{asset.kategori}</Badge>
                      <Badge className={getStatusColor(asset.status)}>
                        {asset.status}
                      </Badge>
                    </CardDescription>
                  </div>
                  {asset.gambar_url && (
                    <div className="w-24 h-24 rounded-lg bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                      <ImageIcon className="h-12 w-12 text-gray-500" />
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-sm font-medium text-gray-600 dark:text-gray-400">Merk</Label>
                    <p className="text-lg">{asset.merk || '-'}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-600 dark:text-gray-400">Model</Label>
                    <p className="text-lg">{asset.model || '-'}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-600 dark:text-gray-400">Serial Number</Label>
                    <p className="text-lg">{asset.serial_number || '-'}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-600 dark:text-gray-400">No Asset ACC</Label>
                    <p className="text-lg">{asset.no_asset_acc || '-'}</p>
                  </div>
                </div>
                
                {asset.assetRadio && (
                  <div className="border-t pt-4">
                    <h4 className="font-semibold mb-3">Informasi Radio RIG</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label className="text-sm font-medium text-gray-600 dark:text-gray-400">Unit Code</Label>
                        <p className="text-lg">{asset.assetRadio.unit_code || '-'}</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-gray-600 dark:text-gray-400">Nama Unit</Label>
                        <p className="text-lg">{asset.assetRadio.nama_unit || '-'}</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-gray-600 dark:text-gray-400">Jenis Unit</Label>
                        <p className="text-lg">{asset.assetRadio.jenis_unit || '-'}</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-gray-600 dark:text-gray-400">UR</Label>
                        <p className="text-lg">{asset.assetRadio.ur || '-'}</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-gray-600 dark:text-gray-400">PO</Label>
                        <p className="text-lg">{asset.assetRadio.po || '-'}</p>
                      </div>
                    </div>
                  </div>
                )}
                
                {asset.assetGeneral && (
                  <div className="border-t pt-4">
                    <h4 className="font-semibold mb-3">Informasi Pengguna</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label className="text-sm font-medium text-gray-600 dark:text-gray-400">User</Label>
                        <p className="text-lg">{asset.assetGeneral.user_name || '-'}</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-gray-600 dark:text-gray-400">NIK</Label>
                        <p className="text-lg">{asset.assetGeneral.nik || '-'}</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-gray-600 dark:text-gray-400">Department</Label>
                        <p className="text-lg">{asset.assetGeneral.department || '-'}</p>
                      </div>
                    </div>
                  </div>
                )}
                
                {asset.catatan && (
                  <div className="border-t pt-4">
                    <Label className="text-sm font-medium text-gray-600 dark:text-gray-400">Catatan</Label>
                    <p className="text-lg mt-1">{asset.catatan}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Asset History */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Clock className="h-5 w-5" />
                      Riwayat Penggunaan
                    </CardTitle>
                    <CardDescription>
                      Total {asset.assetHistories.length} riwayat
                    </CardDescription>
                  </div>
                  <Dialog open={isHistoryDialogOpen} onOpenChange={setIsHistoryDialogOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="h-4 w-4 mr-2" />
                        Tambah Riwayat
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Tambah Riwayat Penggunaan</DialogTitle>
                        <DialogDescription>
                          Tambahkan catatan penggunaan aset
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="pengguna">Pengguna</Label>
                          <Input
                            id="pengguna"
                            value={historyFormData.pengguna}
                            onChange={(e) => setHistoryFormData({ ...historyFormData, pengguna: e.target.value })}
                            placeholder="Masukkan nama pengguna"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="status">Status</Label>
                          <Select value={historyFormData.status} onValueChange={(value) => setHistoryFormData({ ...historyFormData, status: value })}>
                            <SelectTrigger>
                              <SelectValue placeholder="Pilih status" />
                            </SelectTrigger>
                            <SelectContent>
                              {statusOptions.map((status) => (
                                <SelectItem key={status} value={status}>{status}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="catatan">Catatan</Label>
                          <Textarea
                            id="catatan"
                            value={historyFormData.catatan}
                            onChange={(e) => setHistoryFormData({ ...historyFormData, catatan: e.target.value })}
                            placeholder="Masukkan catatan"
                            rows={3}
                          />
                        </div>
                      </div>
                      <div className="flex justify-end gap-2 mt-6">
                        <Button variant="outline" onClick={() => setIsHistoryDialogOpen(false)}>
                          Batal
                        </Button>
                        <Button onClick={handleAddHistory}>
                          Simpan
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                {asset.assetHistories.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    Belum ada riwayat penggunaan
                  </div>
                ) : (
                  <div className="space-y-4">
                    {asset.assetHistories.map((history) => (
                      <div key={history.id} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <User className="h-4 w-4 text-gray-500" />
                            <span className="font-medium">{history.pengguna || 'Tidak diketahui'}</span>
                            {history.status && (
                              <Badge className={getStatusColor(history.status)} variant="secondary">
                                {history.status}
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-2 text-sm text-gray-500">
                            <Calendar className="h-4 w-4" />
                            {formatDate(history.tanggal)}
                          </div>
                        </div>
                        {history.catatan && (
                          <p className="text-gray-600 dark:text-gray-300">{history.catatan}</p>
                        )}
                        <p className="text-xs text-gray-400 mt-2">
                          Ditambahkan oleh {history.user.name}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Informasi Sistem</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-sm font-medium text-gray-600 dark:text-gray-400">ID Aset</Label>
                  <p className="text-sm font-mono">{asset.id}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-600 dark:text-gray-400">Dibuat oleh</Label>
                  <p className="text-sm">{asset.user.name}</p>
                  <p className="text-xs text-gray-500">{asset.user.email}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-600 dark:text-gray-400">Tanggal Dibuat</Label>
                  <p className="text-sm">{formatDate(asset.createdAt)}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-600 dark:text-gray-400">Terakhir Diupdate</Label>
                  <p className="text-sm">{formatDate(asset.updatedAt)}</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Aksi Cepat</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link href={`/assets/${asset.id}/edit`}>
                  <Button variant="outline" className="w-full">
                    <Edit className="h-4 w-4 mr-2" />
                    Edit Aset
                  </Button>
                </Link>
                <Button variant="outline" className="w-full">
                  Cetak Laporan
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}