'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Download, Search, FileSpreadsheet, Filter, Eye } from 'lucide-react'
import Link from 'next/link'

interface Asset {
  id: string
  nama_aset: string
  kategori: string
  merk?: string
  model?: string
  serial_number?: string
  no_asset_acc?: string
  status: string
  catatan?: string
  createdAt: string
  updatedAt: string
  assetRadio?: {
    id: string
    unit_code?: string
    nama_unit?: string
    jenis_unit?: string
    ur?: string
    po?: string
  }
}

const kategoriOptions = [
  'Semua',
  'Radio HT',
  'Radio RIG', 
  'Laptop',
  'Printer',
  'Komputer',
  'Lainnya'
]

const statusOptions = ['Semua', 'Baik', 'Rusak', 'Hilang', 'Maintenance', 'Mutasi']

const jenisUnitOptions = [
  'Semua',
  'HDKM785', 'HDSY95', 'R100', 'R60', 'A40F', 'A60H', 'ADT CAT', 'DWSN80',
  'EXCA LIEBHER', 'EXCA PC2000', 'EXCA HITACHI', 'EXCA VOLVO', 'EXCA KOBELCO',
  'EXCA CAT', 'EXCA SANY', 'EXCA AMPHIBI', 'GREADER', 'BULDOZER', 'WHEEL LOADER',
  'COMPAC', 'DUTRO', 'LOWBOY', 'LONG ARM', 'LV', 'WATER TRUCK', 'FUEL TRUCK',
  'WASHING TRUCK', 'BUS-ELF', 'LUBE TRUCK', 'DT HYUNDAI', 'DT HINO', 'BUILD',
  'CRANE TRUCK', 'DT', 'IZUZU', 'DT RENAULT', 'STOCK', 'HILANG', 'RUSAK', 'MUTASI'
]

export default function ReportsPage() {
  const [assets, setAssets] = useState<Asset[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [kategoriFilter, setKategoriFilter] = useState('Semua')
  const [statusFilter, setStatusFilter] = useState('Semua')
  const [jenisUnitFilter, setJenisUnitFilter] = useState('Semua')

  const fetchAssets = async () => {
    try {
      const response = await fetch('/api/assets')
      if (response.ok) {
        const data = await response.json()
        setAssets(data)
      }
    } catch (error) {
      console.error('Error fetching assets:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchAssets()
  }, [])

  const filteredAssets = assets.filter(asset => {
    const matchesSearch = asset.nama_aset.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         asset.serial_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         asset.no_asset_acc?.toLowerCase().includes(searchTerm.toLowerCase())
    
    const matchesKategori = kategoriFilter === 'Semua' || asset.kategori === kategoriFilter
    const matchesStatus = statusFilter === 'Semua' || asset.status === statusFilter
    const matchesJenisUnit = jenisUnitFilter === 'Semua' || 
                           (asset.assetRadio?.jenis_unit === jenisUnitFilter)

    return matchesSearch && matchesKategori && matchesStatus && matchesJenisUnit
  })

  const exportToExcel = () => {
    // Create CSV content
    const headers = [
      'Nama Aset',
      'Kategori',
      'Merk',
      'Model',
      'Serial Number',
      'No Asset ACC',
      'Status',
      'Catatan',
      'Unit Code',
      'Nama Unit',
      'Jenis Unit',
      'UR',
      'PO',
      'Tanggal Dibuat'
    ]

    const csvContent = [
      headers.join(','),
      ...filteredAssets.map(asset => [
        `"${asset.nama_aset}"`,
        `"${asset.kategori}"`,
        `"${asset.merk || ''}"`,
        `"${asset.model || ''}"`,
        `"${asset.serial_number || ''}"`,
        `"${asset.no_asset_acc || ''}"`,
        `"${asset.status}"`,
        `"${asset.catatan || ''}"`,
        `"${asset.assetRadio?.unit_code || ''}"`,
        `"${asset.assetRadio?.nama_unit || ''}"`,
        `"${asset.assetRadio?.jenis_unit || ''}"`,
        `"${asset.assetRadio?.ur || ''}"`,
        `"${asset.assetRadio?.po || ''}"`,
        `"${new Date(asset.createdAt).toLocaleString('id-ID')}"`
      ].join(','))
    ].join('\n')

    // Create blob and download
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    const url = URL.createObjectURL(blob)
    link.setAttribute('href', url)
    link.setAttribute('download', `laporan_aset_${new Date().toISOString().split('T')[0]}.csv`)
    link.style.visibility = 'hidden'
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Baik': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'
      case 'Rusak': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'
      case 'Hilang': return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300'
      case 'Maintenance': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300'
      case 'Mutasi': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300'
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300'
    }
  }

  const getStatistics = () => {
    const stats = {
      total: filteredAssets.length,
      baik: filteredAssets.filter(a => a.status === 'Baik').length,
      rusak: filteredAssets.filter(a => a.status === 'Rusak').length,
      hilang: filteredAssets.filter(a => a.status === 'Hilang').length,
      maintenance: filteredAssets.filter(a => a.status === 'Maintenance').length,
      mutasi: filteredAssets.filter(a => a.status === 'Mutasi').length,
      radioRig: filteredAssets.filter(a => a.kategori === 'Radio RIG').length,
      radioHT: filteredAssets.filter(a => a.kategori === 'Radio HT').length,
      laptop: filteredAssets.filter(a => a.kategori === 'Laptop').length,
      printer: filteredAssets.filter(a => a.kategori === 'Printer').length,
      komputer: filteredAssets.filter(a => a.kategori === 'Komputer').length,
      lainnya: filteredAssets.filter(a => a.kategori === 'Lainnya').length,
    }
    return stats
  }

  const stats = getStatistics()

  return (
    <div className="bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
      <div className="max-w-7xl mx-auto p-4 md:p-8">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
                Laporan Aset
              </h1>
              <p className="text-gray-600 dark:text-gray-300">
                Laporan dan analisis data aset
              </p>
            </div>
            <Button onClick={exportToExcel}>
              <FileSpreadsheet className="h-4 w-4 mr-2" />
              Export Excel
            </Button>
          </div>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total Aset</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Aset Baik</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{stats.baik}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Aset Rusak</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{stats.rusak}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Radio RIG</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">{stats.radioRig}</div>
            </CardContent>
          </Card>
        </div>

        {/* Category Statistics */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Statistik per Kategori</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">{stats.radioHT}</div>
                <div className="text-sm text-gray-600">Radio HT</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{stats.radioRig}</div>
                <div className="text-sm text-gray-600">Radio RIG</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">{stats.laptop}</div>
                <div className="text-sm text-gray-600">Laptop</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-600">{stats.printer}</div>
                <div className="text-sm text-gray-600">Printer</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-cyan-600">{stats.komputer}</div>
                <div className="text-sm text-gray-600">Komputer</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-600">{stats.lainnya}</div>
                <div className="text-sm text-gray-600">Lainnya</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Filters */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="h-5 w-5" />
              Filter
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Cari aset..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={kategoriFilter} onValueChange={setKategoriFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Kategori" />
                </SelectTrigger>
                <SelectContent>
                  {kategoriOptions.map((kategori) => (
                    <SelectItem key={kategori} value={kategori}>{kategori}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  {statusOptions.map((status) => (
                    <SelectItem key={status} value={status}>{status}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={jenisUnitFilter} onValueChange={setJenisUnitFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Jenis Unit" />
                </SelectTrigger>
                <SelectContent>
                  {jenisUnitOptions.slice(0, 10).map((jenis) => (
                    <SelectItem key={jenis} value={jenis}>{jenis}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Assets Table */}
        <Card>
          <CardHeader>
            <CardTitle>Daftar Aset</CardTitle>
            <CardDescription>
              Total {filteredAssets.length} aset (dari {assets.length} total aset)
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8">Memuat data...</div>
            ) : filteredAssets.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                Tidak ada aset yang ditemukan dengan filter yang dipilih
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nama Aset</TableHead>
                      <TableHead>Kategori</TableHead>
                      <TableHead>Merk/Model</TableHead>
                      <TableHead>Serial Number</TableHead>
                      <TableHead>No Asset ACC</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Jenis Unit</TableHead>
                      <TableHead className="text-center">Aksi</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAssets.map((asset) => (
                      <TableRow key={asset.id}>
                        <TableCell className="font-medium">{asset.nama_aset}</TableCell>
                        <TableCell>
                          <Badge variant="secondary">{asset.kategori}</Badge>
                        </TableCell>
                        <TableCell>
                          {asset.merk && asset.model ? `${asset.merk} ${asset.model}` : asset.merk || asset.model || '-'}
                        </TableCell>
                        <TableCell>{asset.serial_number || '-'}</TableCell>
                        <TableCell>{asset.no_asset_acc || '-'}</TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(asset.status)}>
                            {asset.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{asset.assetRadio?.jenis_unit || '-'}</TableCell>
                        <TableCell>
                          <div className="flex items-center justify-center">
                            <Link href={`/assets/${asset.id}`}>
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="text-blue-600 hover:text-blue-700 hover:bg-blue-50 dark:hover:bg-blue-950 transition-all duration-200"
                                title="Lihat Detail"
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                            </Link>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}