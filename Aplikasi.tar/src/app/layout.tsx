import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";
import { Navbar } from "@/components/navbar";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Sistem Manajemen Aset IT",
  description: "Sistem manajemen aset IT berbasis web untuk mengelola laptop, komputer, printer, radio, dan perangkat lainnya",
  keywords: ["Asset Management", "IT Assets", "Radio RIG", "Inventory", "Next.js", "TypeScript"],
  authors: [{ name: "IT Support Team" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "Sistem Manajemen Aset IT",
    description: "Kelola aset perusahaan dengan mudah dan efisien",
    url: "https://chat.z.ai",
    siteName: "Asset Management",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Sistem Manajemen Aset IT",
    description: "Kelola aset perusahaan dengan mudah dan efisien",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <Navbar />
          <main className="min-h-screen">
            {children}
          </main>
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
