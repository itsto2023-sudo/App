import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const assets = await db.asset.findMany({
      include: {
        assetRadio: true,
        assetGeneral: true,
        user: {
          select: {
            id: true,
            name: true,
            email: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    })

    return NextResponse.json(assets)
  } catch (error) {
    console.error('Error fetching assets:', error)
    return NextResponse.json(
      { error: 'Failed to fetch assets' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      nama_aset,
      kategori,
      merk,
      model,
      serial_number,
      no_asset_acc,
      status,
      catatan,
      unit_code,
      nama_unit,
      jenis_unit,
      ur,
      po,
      user_name,
      nik,
      department
    } = body

    // Create a default user for now (in real app, get from auth)
    let user = await db.user.findFirst()
    if (!user) {
      user = await db.user.create({
        data: {
          email: 'admin@example.com',
          name: 'Admin',
          password: 'temp', // In real app, hash this
          role: 'admin'
        }
      })
    }

    const asset = await db.asset.create({
      data: {
        nama_aset,
        kategori,
        merk: merk || null,
        model: model || null,
        serial_number: serial_number || null,
        no_asset_acc: no_asset_acc || null,
        status: status || 'Baik',
        catatan: catatan || null,
        userId: user.id,
        ...(kategori === 'Radio RIG' && {
          assetRadio: {
            create: {
              nama_aset,
              unit_code: unit_code || null,
              nama_unit: nama_unit || null,
              jenis_unit: jenis_unit || null,
              model: model || null,
              serial_number: serial_number || null,
              no_asset_acc: no_asset_acc || null,
              ur: ur || null,
              po: po || null,
              status: status || 'Baik',
              catatan: catatan || null
            }
          }
        }),
        ...(kategori !== 'Radio RIG' && {
          assetGeneral: {
            create: {
              user_name: user_name || null,
              nik: nik || null,
              department: department || null
            }
          }
        })
      },
      include: {
        assetRadio: true,
        assetGeneral: true,
        user: {
          select: {
            id: true,
            name: true,
            email: true
          }
        }
      }
    })

    return NextResponse.json(asset, { status: 201 })
  } catch (error) {
    console.error('Error creating asset:', error)
    return NextResponse.json(
      { error: 'Failed to create asset' },
      { status: 500 }
    )
  }
}