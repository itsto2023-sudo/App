import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const asset = await db.asset.findUnique({
      where: { id: params.id },
      include: {
        assetRadio: true,
        assetGeneral: true,
        assetHistories: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                email: true
              }
            }
          },
          orderBy: {
            tanggal: 'desc'
          }
        },
        user: {
          select: {
            id: true,
            name: true,
            email: true
          }
        }
      }
    })

    if (!asset) {
      return NextResponse.json(
        { error: 'Asset not found' },
        { status: 404 }
      )
    }

    return NextResponse.json(asset)
  } catch (error) {
    console.error('Error fetching asset:', error)
    return NextResponse.json(
      { error: 'Failed to fetch asset' },
      { status: 500 }
    )
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const {
      nama_aset,
      kategori,
      merk,
      model,
      serial_number,
      no_asset_acc,
      status,
      catatan,
      unit_code,
      nama_unit,
      jenis_unit,
      ur,
      po,
      user_name,
      nik,
      department
    } = body

    const existingAsset = await db.asset.findUnique({
      where: { id: params.id },
      include: { 
        assetRadio: true,
        assetGeneral: true
      }
    })

    if (!existingAsset) {
      return NextResponse.json(
        { error: 'Asset not found' },
        { status: 404 }
      )
    }

    const updateData: any = {
      nama_aset,
      kategori,
      merk: merk || null,
      model: model || null,
      serial_number: serial_number || null,
      no_asset_acc: no_asset_acc || null,
      status: status || 'Baik',
      catatan: catatan || null
    }

    // Handle Radio RIG specific data
    if (kategori === 'Radio RIG') {
      if (existingAsset.assetRadio) {
        // Update existing assetRadio
        await db.assetRadio.update({
          where: { assetId: params.id },
          data: {
            nama_aset,
            unit_code: unit_code || null,
            nama_unit: nama_unit || null,
            jenis_unit: jenis_unit || null,
            model: model || null,
            serial_number: serial_number || null,
            no_asset_acc: no_asset_acc || null,
            ur: ur || null,
            po: po || null,
            status: status || 'Baik',
            catatan: catatan || null
          }
        })
      } else {
        // Create new assetRadio
        updateData.assetRadio = {
          create: {
            nama_aset,
            unit_code: unit_code || null,
            nama_unit: nama_unit || null,
            jenis_unit: jenis_unit || null,
            model: model || null,
            serial_number: serial_number || null,
            no_asset_acc: no_asset_acc || null,
            ur: ur || null,
            po: po || null,
            status: status || 'Baik',
            catatan: catatan || null
          }
        }
      }
      
      // Delete assetGeneral if exists
      if (existingAsset.assetGeneral) {
        await db.assetGeneral.delete({
          where: { assetId: params.id }
        })
      }
    } else {
      // Handle General asset data (Radio HT, Printer, Laptop, Komputer, Lainnya)
      if (existingAsset.assetGeneral) {
        // Update existing assetGeneral
        await db.assetGeneral.update({
          where: { assetId: params.id },
          data: {
            user_name: user_name || null,
            nik: nik || null,
            department: department || null
          }
        })
      } else {
        // Create new assetGeneral
        updateData.assetGeneral = {
          create: {
            user_name: user_name || null,
            nik: nik || null,
            department: department || null
          }
        }
      }
      
      // Delete assetRadio if exists
      if (existingAsset.assetRadio) {
        await db.assetRadio.delete({
          where: { assetId: params.id }
        })
      }
    }

    const asset = await db.asset.update({
      where: { id: params.id },
      data: updateData,
      include: {
        assetRadio: true,
        assetGeneral: true,
        user: {
          select: {
            id: true,
            name: true,
            email: true
          }
        }
      }
    })

    return NextResponse.json(asset)
  } catch (error) {
    console.error('Error updating asset:', error)
    return NextResponse.json(
      { error: 'Failed to update asset' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const asset = await db.asset.findUnique({
      where: { id: params.id }
    })

    if (!asset) {
      return NextResponse.json(
        { error: 'Asset not found' },
        { status: 404 }
      )
    }

    await db.asset.delete({
      where: { id: params.id }
    })

    return NextResponse.json({ message: 'Asset deleted successfully' })
  } catch (error) {
    console.error('Error deleting asset:', error)
    return NextResponse.json(
      { error: 'Failed to delete asset' },
      { status: 500 }
    )
  }
}