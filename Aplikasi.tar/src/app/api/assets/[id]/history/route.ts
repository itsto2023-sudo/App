import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const { pengguna, status, catatan } = body

    // Check if asset exists
    const asset = await db.asset.findUnique({
      where: { id: params.id }
    })

    if (!asset) {
      return NextResponse.json(
        { error: 'Asset not found' },
        { status: 404 }
      )
    }

    // Create a default user for now (in real app, get from auth)
    let user = await db.user.findFirst()
    if (!user) {
      user = await db.user.create({
        data: {
          email: 'admin@example.com',
          name: 'Admin',
          password: 'temp', // In real app, hash this
          role: 'admin'
        }
      })
    }

    const history = await db.assetHistory.create({
      data: {
        assetId: params.id,
        userId: user.id,
        pengguna: pengguna || null,
        status: status || null,
        catatan: catatan || null
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true
          }
        }
      }
    })

    return NextResponse.json(history, { status: 201 })
  } catch (error) {
    console.error('Error creating asset history:', error)
    return NextResponse.json(
      { error: 'Failed to create asset history' },
      { status: 500 }
    )
  }
}