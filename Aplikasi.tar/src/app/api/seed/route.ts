import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST() {
  try {
    // Create default user
    const user = await db.user.upsert({
      where: { email: 'admin@example.com' },
      update: {},
      create: {
        email: 'admin@example.com',
        name: 'Admin',
        password: 'temp123', // In real app, hash this
        role: 'admin'
      }
    })

    // Create sample assets
    const sampleAssets = [
      {
        nama_aset: 'Motorola GP328D',
        kategori: 'Radio HT',
        merk: 'Motorola',
        model: 'GP328D',
        serial_number: 'HT001',
        no_asset_acc: 'ACC001',
        status: 'Baik',
        catatan: 'Radio HT untuk komunikasi tim',
        userId: user.id
      },
      {
        nama_aset: 'Hytera PD785',
        kategori: 'Radio HT',
        merk: 'Hytera',
        model: 'PD785',
        serial_number: 'HT002',
        no_asset_acc: 'ACC002',
        status: 'Baik',
        catatan: 'Radio HT digital',
        userId: user.id
      },
      {
        nama_aset: 'Radio RIG Excavator PC2000',
        kategori: 'Radio RIG',
        merk: 'Kenwood',
        model: 'TK-7180',
        serial_number: 'RIG001',
        no_asset_acc: 'ACC003',
        status: 'Baik',
        catatan: 'Radio RIG untuk excavator',
        unit_code: 'EX001',
        nama_unit: 'Excavator PC2000-1',
        jenis_unit: 'EXCA PC2000',
        ur: 'UR001',
        po: 'PO001',
        userId: user.id
      },
      {
        nama_aset: 'Radio RIG HDKM785',
        kategori: 'Radio RIG',
        merk: 'Motorola',
        model: 'DM4600',
        serial_number: 'RIG002',
        no_asset_acc: 'ACC004',
        status: 'Baik',
        catatan: 'Radio RIG untuk unit HDKM785',
        unit_code: 'HDK001',
        nama_unit: 'HDKM785-01',
        jenis_unit: 'HDKM785',
        ur: 'UR002',
        po: 'PO002',
        userId: user.id
      },
      {
        nama_aset: 'Laptop Dell Latitude 5420',
        kategori: 'Laptop',
        merk: 'Dell',
        model: 'Latitude 5420',
        serial_number: 'LAP001',
        no_asset_acc: 'ACC005',
        status: 'Baik',
        catatan: 'Laptop untuk staff IT',
        userId: user.id
      },
      {
        nama_aset: 'Laptop HP ProBook 440',
        kategori: 'Laptop',
        merk: 'HP',
        model: 'ProBook 440',
        serial_number: 'LAP002',
        no_asset_acc: 'ACC006',
        status: 'Maintenance',
        catatan: 'Laptop sedang dalam perbaikan',
        userId: user.id
      },
      {
        nama_aset: 'Printer Canon LBP2900',
        kategori: 'Printer',
        merk: 'Canon',
        model: 'LBP2900',
        serial_number: 'PRN001',
        no_asset_acc: 'ACC007',
        status: 'Baik',
        catatan: 'Printer laser untuk kantor',
        userId: user.id
      },
      {
        nama_aset: 'Komputer Dell OptiPlex',
        kategori: 'Komputer',
        merk: 'Dell',
        model: 'OptiPlex 7090',
        serial_number: 'PC001',
        no_asset_acc: 'ACC008',
        status: 'Baik',
        catatan: 'PC untuk administrasi',
        userId: user.id
      }
    ]

    for (const assetData of sampleAssets) {
      const { unit_code, nama_unit, jenis_unit, ur, po, ...baseAssetData } = assetData
      
      const asset = await db.asset.create({
        data: {
          ...baseAssetData,
          ...(assetData.kategori === 'Radio RIG' && {
            assetRadio: {
              create: {
                nama_aset: assetData.nama_aset,
                unit_code: unit_code || null,
                nama_unit: nama_unit || null,
                jenis_unit: jenis_unit || null,
                model: assetData.model || null,
                serial_number: assetData.serial_number || null,
                no_asset_acc: assetData.no_asset_acc || null,
                ur: ur || null,
                po: po || null,
                status: assetData.status,
                catatan: assetData.catatan || null
              }
            }
          })
        }
      })

      // Add sample history
      if (assetData.kategori === 'Radio RIG') {
        await db.assetHistory.create({
          data: {
            assetId: asset.id,
            userId: user.id,
            pengguna: 'Operator Excavator',
            status: 'Baik',
            catatan: 'Unit digunakan untuk operasional harian'
          }
        })
      }
    }

    return NextResponse.json({ 
      message: 'Sample data created successfully',
      assetsCreated: sampleAssets.length
    })
  } catch (error) {
    console.error('Error seeding data:', error)
    return NextResponse.json(
      { error: 'Failed to seed data' },
      { status: 500 }
    )
  }
}