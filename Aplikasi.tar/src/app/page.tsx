'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Radio, Laptop, Printer, Monitor, Package, Settings } from 'lucide-react'
import Link from 'next/link'

const kategoriAset = [
  {
    nama: 'Radio HT',
    icon: Radio,
    warna: 'bg-blue-500',
    deskripsi: 'Radio Handy Talky',
    href: '/assets?kategori=Radio HT'
  },
  {
    nama: 'Radio RIG',
    icon: Settings,
    warna: 'bg-green-500',
    deskripsi: 'Radio RIG dengan berbagai jenis unit',
    href: '/assets?kategori=Radio RIG'
  },
  {
    nama: 'Laptop',
    icon: Laptop,
    warna: 'bg-purple-500',
    deskripsi: 'Perangkat laptop dan notebook',
    href: '/assets?kategori=Laptop'
  },
  {
    nama: 'Printer',
    icon: Printer,
    warna: 'bg-orange-500',
    deskripsi: 'Printer dan scanner',
    href: '/assets?kategori=Printer'
  },
  {
    nama: 'Komputer',
    icon: Monitor,
    warna: 'bg-cyan-500',
    deskripsi: 'PC dan komputer desktop',
    href: '/assets?kategori=Komputer'
  },
  {
    nama: 'Lainnya',
    icon: Package,
    warna: 'bg-gray-500',
    deskripsi: 'Aset lainnya',
    href: '/assets?kategori=Lainnya'
  }
]

export default function Home() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  return (
    <div className="bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
      <div className="max-w-7xl mx-auto p-4 md:p-8">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-2">
                Sistem Manajemen Aset IT
              </h1>
              <p className="text-gray-600 dark:text-gray-300">
                Kelola aset perusahaan dengan mudah dan efisien
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {kategoriAset.map((kategori) => {
            const Icon = kategori.icon
            return (
              <Link key={kategori.nama} href={kategori.href}>
                <Card className="group hover:shadow-lg transition-all duration-200 hover:-translate-y-1 cursor-pointer">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className={`p-3 rounded-lg ${kategori.warna} bg-opacity-10 group-hover:bg-opacity-20 transition-colors`}>
                        <Icon className={`h-6 w-6 ${kategori.warna.replace('bg-', 'text-')}`} />
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        Lihat Detail
                      </Badge>
                    </div>
                    <CardTitle className="text-lg">{kategori.nama}</CardTitle>
                    <CardDescription className="text-sm">
                      {kategori.deskripsi}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button variant="ghost" className="w-full group-hover:bg-gray-100 dark:group-hover:bg-gray-800 transition-colors">
                      Kelola {kategori.nama}
                    </Button>
                  </CardContent>
                </Card>
              </Link>
            )
          })}
        </div>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Fitur Utama</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-sm text-gray-600 dark:text-gray-300">
                  Manajemen aset lengkap dengan CRUD
                </span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-sm text-gray-600 dark:text-gray-300">
                  Upload gambar aset
                </span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-sm text-gray-600 dark:text-gray-300">
                  Riwayat penggunaan aset
                </span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-sm text-gray-600 dark:text-gray-300">
                  Export/Import Excel
                </span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Kategori Radio RIG</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2 mb-4">
                {['HDKM785', 'HDSY95', 'R100', 'R60', 'A40F', 'A60H'].map((jenis) => (
                  <Badge key={jenis} variant="outline" className="text-xs">
                    {jenis}
                  </Badge>
                ))}
                <Badge variant="outline" className="text-xs">
                  +25 lainnya
                </Badge>
              </div>
              <Link href="/reports">
                <Button variant="outline" className="w-full">
                  Lihat Laporan Lengkap
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}