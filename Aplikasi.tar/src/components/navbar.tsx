'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { ThemeToggle } from '@/components/theme-toggle'
import { ArrowLeft, Home, FileSpreadsheet, Package } from 'lucide-react'

export function Navbar() {
  const pathname = usePathname()

  const getNavTitle = () => {
    if (pathname === '/') return 'Dashboard'
    if (pathname.startsWith('/assets')) {
      if (pathname === '/assets') return 'Daftar Aset'
      return 'Detail Aset'
    }
    if (pathname === '/reports') return 'Laporan'
    return 'Sistem Manajemen Aset IT'
  }

  const showBackButton = pathname !== '/'

  return (
    <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-4">
            {showBackButton && (
              <Link href="/">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Kembali
                </Button>
              </Link>
            )}
            <div>
              <h1 className="text-lg font-semibold">{getNavTitle()}</h1>
              <p className="text-sm text-muted-foreground">
                {pathname === '/' && 'Kelola aset perusahaan dengan mudah'}
                {pathname.startsWith('/assets') && 'Manajemen data aset'}
                {pathname === '/reports' && 'Laporan dan analisis data'}
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Link href="/">
              <Button variant={pathname === '/' ? 'default' : 'ghost'} size="sm">
                <Home className="h-4 w-4 mr-2" />
                Dashboard
              </Button>
            </Link>
            <Link href="/assets">
              <Button variant={pathname.startsWith('/assets') ? 'default' : 'ghost'} size="sm">
                <Package className="h-4 w-4 mr-2" />
                Aset
              </Button>
            </Link>
            <Link href="/reports">
              <Button variant={pathname === '/reports' ? 'default' : 'ghost'} size="sm">
                <FileSpreadsheet className="h-4 w-4 mr-2" />
                Laporan
              </Button>
            </Link>
            <ThemeToggle />
          </div>
        </div>
      </div>
    </nav>
  )
}