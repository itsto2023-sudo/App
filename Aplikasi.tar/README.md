# 🏢 Sistem Manajemen Aset IT

> Sistem manajemen aset perusahaan yang modern, responsif, dan mudah digunakan.

[![Next.js](https://img.shields.io/badge/Next.js-15-black?style=for-the-badge&logo=next.js)](https://nextjs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5-blue?style=for-the-badge&logo=typescript)](https://www.typescriptlang.org/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind-4-38B2AC?style=for-the-badge&logo=tailwind-css)](https://tailwindcss.com/)
[![Prisma](https://img.shields.io/badge/Prisma-5-2D3748?style=for-the-badge&logo=prisma)](https://www.prisma.io/)

## ✨ Fitur Utama

- 🎯 **Multi-Kategori Aset**: Radio HT, Radio RIG, Laptop, Printer, Komputer, Lainnya
- 👥 **User Management**: Tracking user, NIK, dan department (10 department tersedia)
- 📊 **Real-time Dashboard**: Statistik lengkap dan visualisasi data
- 🔍 **Advanced Search**: Filter berdasarkan kategori, status, dan pencarian
- 📱 **Responsive Design**: Optimal di desktop, tablet, dan mobile
- 📈 **Data Export**: Export ke CSV untuk reporting
- 🔄 **Asset History**: Track riwayat penggunaan aset
- 🎨 **Modern UI**: shadcn/ui components dengan Tailwind CSS

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ 
- npm atau yarn

### Installation
```bash
# Clone repository
git clone <repository-url>
cd manajemen-aset-it

# Install dependencies
npm install

# Setup database
npx prisma generate
npx prisma db push

# Start development server
npm run dev
```

Buka [http://localhost:3000](http://localhost:3000) di browser Anda.

## 📸 Screenshots

### Dashboard
![Dashboard](https://via.placeholder.com/800x400/1a1a1a/ffffff?text=Modern+Asset+Management+Dashboard)

### Asset List
![Asset List](https://via.placeholder.com/800x400/1a1a1a/ffffff?text=Asset+List+with+Advanced+Filtering)

### Asset Detail
![Asset Detail](https://via.placeholder.com/800x400/1a1a1a/ffffff?text=Detailed+Asset+Information+with+History)

## 🏗️ Teknologi Stack

| Technology | Version | Description |
|------------|---------|-------------|
| **Framework** | Next.js 15 | React framework dengan App Router |
| **Language** | TypeScript 5 | Type-safe JavaScript |
| **Styling** | Tailwind CSS 4 | Utility-first CSS framework |
| **UI Components** | shadcn/ui | Modern React components |
| **Database** | SQLite + Prisma | Lightweight database dengan ORM |
| **Authentication** | NextAuth.js | Authentication solution |
| **State Management** | Zustand + TanStack Query | Client dan server state management |

## 📁 Project Structure

```
manajemen-aset-it/
├── 📂 prisma/
│   └── 📄 schema.prisma          # Database schema
├── 📂 src/
│   ├── 📂 app/
│   │   ├── 📂 api/              # API routes
│   │   ├── 📂 assets/           # Asset management pages
│   │   ├── 📂 reports/          # Reports page
│   │   ├── 📄 globals.css       # Global styles
│   │   ├── 📄 layout.tsx        # Root layout
│   │   └── 📄 page.tsx          # Homepage
│   ├── 📂 components/
│   │   └── 📂 ui/               # shadcn/ui components
│   ├── 📂 lib/
│   │   ├── 📄 db.ts             # Database connection
│   │   └── 📄 utils.ts          # Utility functions
│   └── 📂 hooks/
│       └── 📄 use-toast.ts      # Toast notifications
├── 📂 public/                   # Static assets
├── 📄 package.json             # Dependencies
├── 📄 tailwind.config.ts       # Tailwind config
└── 📄 README.md                # This file
```

## 🎯 Kategori Aset

| Kategori | Deskripsi | Field Khusus |
|----------|-----------|--------------|
| 📻 **Radio HT** | Radio Handy Talky | User, NIK, Department |
| 📡 **Radio RIG** | Radio RIG Station | Unit Code, Nama Unit, Jenis Unit, UR, PO |
| 💻 **Laptop** | Perangkat laptop | User, NIK, Department |
| 🖨️ **Printer** | Printer & Scanner | User, NIK, Department |
| 🖥️ **Komputer** | PC Desktop | User, NIK, Department |
| 📦 **Lainnya** | Aset lainnya | User, NIK, Department |

## 🏢 Department Options

Sistem mendukung 10 department:
- **ICTs** - Information & Communication Technology
- **HGAs** - Human Resources & General Affairs
- **LOGs** - Logistics
- **ENGs** - Engineering
- **SHEs** - Safety, Health & Environment
- **PDCs** - Project Development & Control
- **PLTs** - Plant
- **FINs** - Finance
- **TCNs** - Technical & Non-Technical
- **SKUs** - Stock Keeping Units

## 📊 API Endpoints

### Assets
- `GET /api/assets` - Get all assets
- `POST /api/assets` - Create new asset
- `GET /api/assets/[id]` - Get asset by ID
- `PUT /api/assets/[id]` - Update asset
- `DELETE /api/assets/[id]` - Delete asset

### Asset History
- `GET /api/assets/[id]/history` - Get asset history
- `POST /api/assets/[id]/history` - Add history entry

### Utilities
- `GET /api/health` - Health check
- `POST /api/seed` - Seed sample data

## 🛠️ Development

### Available Scripts
```bash
npm run dev          # Start development server
npm run build        # Build for production
npm run start        # Start production server
npm run lint         # Run ESLint
npm run type-check   # Run TypeScript check
```

### Database Operations
```bash
npx prisma generate  # Generate Prisma client
npx prisma db push   # Push schema to database
npx prisma studio    # Open Prisma Studio
npx prisma db seed   # Seed database (if configured)
```

## 🚀 Deployment

### Environment Variables
```env
DATABASE_URL="file:./dev.db"
NEXTAUTH_SECRET="your-secret-key"
NEXTAUTH_URL="http://localhost:3000"
```

### Build for Production
```bash
npm run build
npm start
```

### Docker Deployment
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
```

## 📱 Mobile Support

Aplikasi fully responsive dengan:
- ✅ Touch-friendly interface
- ✅ Optimized tables untuk mobile
- ✅ Swipe gestures
- ✅ Progressive Web App ready

## 🔒 Security Features

- ✅ Input validation
- ✅ SQL injection prevention (Prisma ORM)
- ✅ XSS protection
- ✅ CSRF protection
- ✅ Secure headers

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 📞 Support

- 📧 Email: support@company.com
- 💬 Discord: [Join our community](https://discord.gg/invite)
- 📖 Documentation: [Full Guide](./TUTORIAL_PASANG.md)
- 🚀 Quick Start: [5-Minute Setup](./QUICK_START.md)

## 🎉 Roadmap

- [ ] 📸 Image upload untuk assets
- [ ] 📊 Advanced analytics dashboard
- [ ] 👥 Multi-user authentication
- [ ] 📱 Mobile app (React Native)
- [ ] 🔔 Real-time notifications
- [ ] 📋 Barcode/QR code scanning
- [ ] 📈 Predictive maintenance
- [ ] 🌐 Multi-language support

---

**Made with ❤️ by IT Team**

> *Efficient asset management for modern enterprises*