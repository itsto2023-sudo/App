# 🚀 Deployment Guide

## 📋 Overview

Guide lengkap untuk deployment Sistem Manajemen Aset IT di berbagai environment.

---

## 🏠 Local Development

### Prerequisites
- Node.js 18+
- npm atau yarn
- Git

### Quick Start
```bash
# Clone repository
git clone <repository-url>
cd manajemen-aset-it

# Install dependencies
npm install

# Setup database
npx prisma generate
npx prisma db push

# Start development server
npm run dev
```

Access: http://localhost:3000

---

## 🐳 Docker Deployment

### Development with Docker
```bash
# Build image
docker build -t manajemen-aset-it .

# Run container
docker run -p 3000:3000 -e DATABASE_URL="file:./dev.db" manajemen-aset-it
```

### Production with Docker Compose
```bash
# Start services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

### Environment Variables for Docker
```yaml
# docker-compose.override.yml
version: '3.8'
services:
  app:
    environment:
      - NODE_ENV=production
      - DATABASE_URL=file:./prod.db
      - NEXTAUTH_SECRET=your-super-secret-key-here
      - NEXTAUTH_URL=https://your-domain.com
      - ZAI_API_KEY=your-zai-api-key
```

---

## ☁️ Cloud Deployment

### Vercel (Recommended)

#### 1. Install Vercel CLI
```bash
npm i -g vercel
```

#### 2. Deploy
```bash
# Login to Vercel
vercel login

# Deploy project
vercel

# Deploy to production
vercel --prod
```

#### 3. Environment Variables in Vercel
```bash
# Set environment variables
vercel env add DATABASE_URL
vercel env add NEXTAUTH_SECRET
vercel env add NEXTAUTH_URL
vercel env add ZAI_API_KEY
```

#### 4. Database Setup
```bash
# Deploy Prisma to Vercel
npx prisma db push
```

### Netlify

#### 1. Build Configuration
```toml
# netlify.toml
[build]
  command = "npm run build"
  publish = ".next"

[build.environment]
  NODE_VERSION = "18"

[[redirects]]
  from = "/api/*"
  to = "/.netlify/functions/:splat"
  status = 200
```

#### 2. Deploy
```bash
# Install Netlify CLI
npm install -g netlify-cli

# Deploy
netlify deploy --prod
```

### Railway

#### 1. Install Railway CLI
```bash
npm install -g @railway/cli
```

#### 2. Deploy
```bash
# Login
railway login

# Initialize project
railway init

# Deploy
railway up
```

#### 3. Environment Variables
```bash
# Set environment variables
railway variables set DATABASE_URL="file:./prod.db"
railway variables set NEXTAUTH_SECRET="your-secret"
railway variables set NEXTAUTH_URL="https://your-app.railway.app"
```

---

## 🖥️ VPS Deployment

### Ubuntu/Debian Setup

#### 1. Update System
```bash
sudo apt update && sudo apt upgrade -y
```

#### 2. Install Node.js
```bash
# Install Node.js 18
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Verify installation
node --version
npm --version
```

#### 3. Install PM2
```bash
sudo npm install -g pm2
```

#### 4. Clone and Setup
```bash
# Clone repository
git clone <repository-url> /var/www/manajemen-aset-it
cd /var/www/manajemen-aset-it

# Install dependencies
npm install --production

# Setup database
npx prisma generate
npx prisma db push

# Build application
npm run build
```

#### 5. PM2 Configuration
```javascript
// ecosystem.config.js
module.exports = {
  apps: [{
    name: 'manajemen-aset-it',
    script: 'npm',
    args: 'start',
    cwd: '/var/www/manajemen-aset-it',
    instances: 'max',
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    error_file: '/var/log/manajemen-aset-it/error.log',
    out_file: '/var/log/manajemen-aset-it/out.log',
    log_file: '/var/log/manajemen-aset-it/combined.log',
    time: true
  }]
}
```

#### 6. Start Application
```bash
# Create log directory
sudo mkdir -p /var/log/manajemen-aset-it

# Start with PM2
pm2 start ecosystem.config.js

# Save PM2 configuration
pm2 save

# Setup PM2 startup
pm2 startup
```

### Nginx Reverse Proxy

#### 1. Install Nginx
```bash
sudo apt install nginx -y
```

#### 2. Configure Nginx
```nginx
# /etc/nginx/sites-available/manajemen-aset-it
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

#### 3. Enable Site
```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/manajemen-aset-it /etc/nginx/sites-enabled/

# Test configuration
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx
```

### SSL with Let's Encrypt

#### 1. Install Certbot
```bash
sudo apt install certbot python3-certbot-nginx -y
```

#### 2. Get SSL Certificate
```bash
sudo certbot --nginx -d your-domain.com
```

#### 3. Auto Renewal
```bash
# Test auto-renewal
sudo certbot renew --dry-run

# Certbot automatically sets up cron job
```

---

## 🔧 Configuration

### Environment Variables

#### Development
```env
# .env.local
DATABASE_URL="file:./dev.db"
NEXTAUTH_SECRET="dev-secret-key"
NEXTAUTH_URL="http://localhost:3000"
ZAI_API_KEY="your-zai-api-key"
```

#### Production
```env
# .env.production
DATABASE_URL="file:./prod.db"
NEXTAUTH_SECRET="super-secure-production-secret"
NEXTAUTH_URL="https://your-domain.com"
ZAI_API_KEY="your-production-zai-api-key"
```

### Database Configuration

#### SQLite (Default)
```env
DATABASE_URL="file:./prod.db"
```

#### PostgreSQL (Production Recommended)
```env
DATABASE_URL="postgresql://username:password@localhost:5432/asset_management"
```

#### MySQL
```env
DATABASE_URL="mysql://username:password@localhost:3306/asset_management"
```

---

## 🔍 Monitoring & Logging

### Application Monitoring

#### PM2 Monitoring
```bash
# View process status
pm2 status

# View logs
pm2 logs

# Monitor dashboard
pm2 monit

# Restart application
pm2 restart manajemen-aset-it
```

#### Health Check
```bash
# Check application health
curl http://localhost:3000/api/health

# Expected response
{
  "status": "healthy",
  "timestamp": "2024-01-01T00:00:00.000Z",
  "database": "connected"
}
```

### Log Management

#### Application Logs
```bash
# View PM2 logs
pm2 logs manajemen-aset-it

# View Nginx logs
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log

# View system logs
sudo journalctl -u nginx -f
```

#### Log Rotation
```bash
# Configure log rotation
sudo nano /etc/logrotate.d/manajemen-aset-it
```

```
/var/log/manajemen-aset-it/*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    create 644 www-data www-data
    postrotate
        pm2 reloadLogs
    endscript
}
```

---

## 🔒 Security

### Security Headers
```nginx
add_header X-Frame-Options "SAMEORIGIN" always;
add_header X-XSS-Protection "1; mode=block" always;
add_header X-Content-Type-Options "nosniff" always;
add_header Referrer-Policy "no-referrer-when-downgrade" always;
add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;
```

### Firewall Configuration
```bash
# Configure UFW
sudo ufw allow ssh
sudo ufw allow 'Nginx Full'
sudo ufw enable
```

### Rate Limiting
```nginx
limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
limit_req_zone $binary_remote_addr zone=general:10m rate=30r/s;
```

---

## 🔄 CI/CD Pipeline

### GitHub Actions

#### 1. Create Workflow
```yaml
# .github/workflows/deploy.yml
name: Deploy to Production

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        cache: 'npm'
    
    - name: Install dependencies
      run: npm ci
    
    - name: Run tests
      run: npm test
    
    - name: Build application
      run: npm run build
      env:
        NEXTAUTH_SECRET: ${{ secrets.NEXTAUTH_SECRET }}
        DATABASE_URL: ${{ secrets.DATABASE_URL }}
    
    - name: Deploy to server
      uses: appleboy/ssh-action@v0.1.5
      with:
        host: ${{ secrets.HOST }}
        username: ${{ secrets.USERNAME }}
        key: ${{ secrets.SSH_KEY }}
        script: |
          cd /var/www/manajemen-aset-it
          git pull origin main
          npm install --production
          npm run build
          pm2 restart manajemen-aset-it
```

#### 2. Add Secrets
- `NEXTAUTH_SECRET`
- `DATABASE_URL`
- `HOST`
- `USERNAME`
- `SSH_KEY`

---

## 📊 Performance Optimization

### Database Optimization
```sql
-- Create indexes for better performance
CREATE INDEX idx_assets_kategori ON assets(kategori);
CREATE INDEX idx_assets_status ON assets(status);
CREATE INDEX idx_asset_histories_tanggal ON asset_histories(tanggal);
```

### Caching Strategy
```javascript
// Implement Redis caching (optional)
import Redis from 'ioredis';

const redis = new Redis(process.env.REDIS_URL);

// Cache API responses
app.get('/api/assets', async (req, res) => {
  const cacheKey = 'assets:all';
  const cached = await redis.get(cacheKey);
  
  if (cached) {
    return res.json(JSON.parse(cached));
  }
  
  const assets = await getAssets();
  await redis.setex(cacheKey, 300, JSON.stringify(assets));
  
  res.json(assets);
});
```

---

## 🚨 Troubleshooting

### Common Issues

#### 1. Database Connection Error
```bash
# Check database file permissions
ls -la prisma/dev.db

# Fix permissions
chmod 664 prisma/dev.db
chown www-data:www-data prisma/dev.db
```

#### 2. Port Already in Use
```bash
# Find process using port 3000
lsof -ti:3000

# Kill process
kill -9 $(lsof -ti:3000)
```

#### 3. Memory Issues
```bash
# Check memory usage
free -h

# Check Node.js process memory
pm2 monit

# Increase Node.js memory limit
node --max-old-space-size=4096 server.js
```

#### 4. Build Errors
```bash
# Clear Next.js cache
rm -rf .next

# Clear npm cache
npm cache clean --force

# Reinstall dependencies
rm -rf node_modules package-lock.json
npm install
```

### Health Monitoring
```bash
# Create health check script
#!/bin/bash
# health-check.sh

response=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/api/health)

if [ $response != "200" ]; then
    echo "Application is down. Restarting..."
    pm2 restart manajemen-aset-it
    # Send notification
    curl -X POST -H 'Content-type: application/json' \
        --data '{"text":"🚨 Asset Management System is down!"}' \
        YOUR_SLACK_WEBHOOK_URL
fi
```

---

## 📞 Support

### Monitoring Services
- **Uptime Robot**: Monitor application uptime
- **Sentry**: Error tracking and performance monitoring
- **LogRocket**: User session recording
- **Grafana**: Custom dashboards and metrics

### Backup Strategy
```bash
# Database backup script
#!/bin/bash
# backup.sh

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/var/backups/manajemen-aset-it"

mkdir -p $BACKUP_DIR

# Backup database
cp /var/www/manajemen-aset-it/prisma/prod.db $BACKUP_DIR/prod_$DATE.db

# Backup application files
tar -czf $BACKUP_DIR/app_$DATE.tar.gz /var/www/manajemen-aset-it

# Clean old backups (keep last 30 days)
find $BACKUP_DIR -name "*.db" -mtime +30 -delete
find $BACKUP_DIR -name "*.tar.gz" -mtime +30 -delete
```

---

## 🎉 Production Ready Checklist

- [ ] Environment variables configured
- [ ] SSL certificate installed
- [ ] Database backed up
- [ ] Monitoring configured
- [ ] Log rotation setup
- [ ] Firewall configured
- [ ] Rate limiting enabled
- [ ] Security headers added
- [ ] Backup automation setup
- [ ] Health checks configured
- [ ] Performance monitoring active
- [ ] Error tracking setup
- [ ] CI/CD pipeline configured
- [ ] Documentation updated
- [ ] Team trained

**🚀 Your Sistem Manajemen Aset IT is now production ready!**