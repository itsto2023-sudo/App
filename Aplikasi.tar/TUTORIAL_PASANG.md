# 🚀 Tutorial Pemasangan Sistem Manajemen Aset IT

## 📋 Deskripsi
Sistem Manajemen Aset IT adalah aplikasi web berbasis Next.js 15 dengan TypeScript untuk mengelola aset perusahaan seperti Radio HT, Radio RIG, Laptop, Printer, Komputer, dan lainnya.

## 🛠️ Teknologi yang Digunakan
- **Framework**: Next.js 15 dengan App Router
- **Bahasa**: TypeScript 5
- **Styling**: Tailwind CSS 4
- **UI Components**: shadcn/ui
- **Database**: SQLite dengan Prisma ORM
- **Authentication**: NextAuth.js v4
- **State Management**: Zustand + TanStack Query

---

## 📋 Prasyarat
Sebelum memulai, pastikan Anda telah menginstall:

### Software Wajib
```bash
# Node.js (versi 18 atau lebih tinggi)
node --version

# npm (biasanya sudah terinstall dengan Node.js)
npm --version

# Git (untuk version control)
git --version
```

### Software Opsional (Recommended)
```bash
# Visual Studio Code (code editor)
# Atau code editor favorit Anda

# Postman/Insomnia (untuk testing API)
# Atau bisa menggunakan curl/built-in fetch
```

---

## 🗂️ Struktur Folder Project
```
my-project/
├── prisma/
│   └── schema.prisma          # Database schema
├── src/
│   ├── app/
│   │   ├── api/              # API routes
│   │   ├── assets/           # Halaman assets
│   │   ├── reports/          # Halaman laporan
│   │   ├── globals.css       # Global styles
│   │   ├── layout.tsx        # Root layout
│   │   └── page.tsx          # Halaman utama
│   ├── components/
│   │   └── ui/               # shadcn/ui components
│   ├── lib/
│   │   ├── db.ts             # Database connection
│   │   └── utils.ts          # Utility functions
│   └── hooks/
│       └── use-toast.ts      # Toast notification hook
├── public/                   # Static files
├── package.json             # Dependencies & scripts
├── tailwind.config.ts       # Tailwind configuration
├── next.config.ts           # Next.js configuration
└── README.md                # Project documentation
```

---

## 📦 Langkah 1: Setup Project Baru

### 1.1 Buat Project Next.js
```bash
# Buat project Next.js baru dengan TypeScript
npx create-next-app@latest manajemen-aset-it --typescript --tailwind --eslint --app --src-dir --import-alias "@/*"

# Masuk ke folder project
cd manajemen-aset-it
```

### 1.2 Install Dependencies
```bash
# Install dependencies utama
npm install @prisma/client prisma
npm install next-auth
npm install zustand @tanstack/react-query
npm install lucide-react
npm install class-variance-authority clsx tailwind-merge

# Install dev dependencies
npm install -D @types/node
```

### 1.3 Setup shadcn/ui
```bash
# Initialize shadcn/ui
npx shadcn-ui@latest init

# Install required components
npx shadcn-ui@latest add button
npx shadcn-ui@latest add card
npx shadcn-ui@latest add input
npx shadcn-ui@latest add label
npx shadcn-ui@latest add select
npx shadcn-ui@latest add textarea
npx shadcn-ui@latest add table
npx shadcn-ui@latest add dialog
npx shadcn-ui@latest add badge
```

---

## 🗄️ Langkah 2: Setup Database

### 2.1 Initialize Prisma
```bash
# Initialize Prisma
npx prisma init --datasource-provider sqlite
```

### 2.2 Buat Database Schema
Edit file `prisma/schema.prisma`:
```prisma
// This is your Prisma schema file,
// learn more about it in the docs: https://pris.ly/d/prisma-schema

generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "sqlite"
  url      = "file:./dev.db"
}

model User {
  id        String   @id @default(cuid())
  email     String   @unique
  name      String
  password  String
  role      String   @default("user")
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  assets         Asset[]
  assetHistories AssetHistory[]
}

model Asset {
  id            String   @id @default(cuid())
  nama_aset     String
  kategori      String
  merk          String?
  model         String?
  serial_number String?
  no_asset_acc  String?
  status        String   @default("Baik")
  catatan       String?
  gambar_url    String?
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt
  userId        String

  user          User           @relation(fields: [userId], references: [id])
  assetRadio    AssetRadio?
  assetGeneral  AssetGeneral?
  assetHistories AssetHistory[]

  @@map("assets")
}

model AssetRadio {
  id            String   @id @default(cuid())
  nama_aset     String
  unit_code     String?
  nama_unit     String?
  jenis_unit    String?
  model         String?
  serial_number String?
  no_asset_acc  String?
  ur            String?
  po            String?
  status        String   @default("Baik")
  catatan       String?
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt
  assetId       String   @unique

  asset         Asset @relation(fields: [assetId], references: [id], onDelete: Cascade)

  @@map("asset_radios")
}

model AssetGeneral {
  id         String   @id @default(cuid())
  user_name  String?
  nik        String?
  department String?
  createdAt  DateTime @default(now())
  updatedAt  DateTime @updatedAt
  assetId    String   @unique

  asset      Asset @relation(fields: [assetId], references: [id], onDelete: Cascade)

  @@map("asset_generals")
}

model AssetHistory {
  id        String   @id @default(cuid())
  assetId   String
  userId    String
  pengguna  String?
  status    String?
  catatan   String?
  tanggal   DateTime @default(now())
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  asset     Asset @relation(fields: [assetId], references: [id], onDelete: Cascade)
  user      User  @relation(fields: [userId], references: [id])

  @@map("asset_histories")
}
```

### 2.3 Generate Prisma Client
```bash
# Generate Prisma client
npx prisma generate

# Push schema ke database
npx prisma db push
```

---

## 📁 Langkah 3: Setup File Project

### 3.1 Buat Database Connection
Buat file `src/lib/db.ts`:
```typescript
import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const db = globalForPrisma.prisma ?? new PrismaClient()

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
```

### 3.2 Setup Environment Variables
Buat file `.env.local`:
```env
# Database
DATABASE_URL="file:./dev.db"

# NextAuth
NEXTAUTH_SECRET="your-secret-key-here"
NEXTAUTH_URL="http://localhost:3000"

# Z-AI Web Dev SDK (jika digunakan)
ZAI_API_KEY="your-zai-api-key"
```

### 3.3 Copy Source Code
Salin semua file dari project yang sudah ada ke folder project baru Anda:

```bash
# Salin folder src (kecuali node_modules)
cp -r /path/to/original/src/* ./src/

# Salin file konfigurasi
cp /path/to/original/tailwind.config.ts ./
cp /path/to/original/next.config.ts ./
cp /path/to/original/package.json ./

# Install dependencies yang ada di package.json
npm install
```

---

## 🚀 Langkah 4: Jalankan Aplikasi

### 4.1 Install Dependencies
```bash
# Install semua dependencies
npm install

# Generate Prisma client lagi
npx prisma generate

# Push schema ke database
npx prisma db push
```

### 4.2 Seed Database (Opsional)
Jika ada file seeding, jalankan:
```bash
# Jalankan seeding jika ada
npm run seed
# Atau akses langsung via browser
# http://localhost:3000/api/seed
```

### 4.3 Start Development Server
```bash
# Jalankan development server
npm run dev

# Atau
yarn dev
```

### 4.4 Verifikasi Instalasi
Buka browser dan akses:
- **Homepage**: http://localhost:3000
- **Assets**: http://localhost:3000/assets
- **Reports**: http://localhost:3000/reports

---

## 🔧 Langkah 5: Konfigurasi Tambahan

### 5.1 Setup Git (Opsional)
```bash
# Initialize Git repository
git init

# Add .gitignore
echo "node_modules/
.next/
.env.local
.env.development.local
.env.test.local
.env.production.local
dist/
build/
*.log
.DS_Store
" > .gitignore

# Initial commit
git add .
git commit -m "Initial commit: Manajemen Aset IT System"
```

### 5.2 Setup Production Build
```bash
# Build untuk production
npm run build

# Start production server
npm start
```

---

## 📱 Langkah 6: Penggunaan Aplikasi

### 6.1 Navigasi Utama
1. **Homepage**: Dashboard dengan kategori aset
2. **Assets**: Daftar lengkap aset dengan fitur CRUD
3. **Detail Asset**: Informasi detail dan riwayat penggunaan
4. **Reports**: Laporan dan statistik aset

### 6.2 Fitur Utama
- ✅ **Tambah Aset**: Tambah aset baru dengan form dinamis
- ✅ **Edit Aset**: Update informasi aset
- ✅ **Hapus Aset**: Hapus aset (dengan konfirmasi)
- ✅ **Filter & Search**: Filter berdasarkan kategori, status, dan pencarian
- ✅ **Export**: Export data ke CSV
- ✅ **Riwayat**: Track riwayat penggunaan aset

### 6.3 Kategori Aset
- **Radio HT**: Handy Talky
- **Radio RIG**: Radio RIG dengan informasi unit
- **Laptop**: Perangkat laptop dan notebook
- **Printer**: Printer dan scanner
- **Komputer**: PC dan komputer desktop
- **Lainnya**: Aset lainnya

### 6.4 Department Options
Sistem mendukung 10 department:
- ICTs
- HGAs
- LOGs
- ENGs
- SHEs
- PDCs
- PLTs
- FINs
- TCNs
- SKUs

---

## 🐛 Troubleshooting

### Masalah Umum & Solusi

#### 1. Port 3000 Sudah Digunakan
```bash
# Kill process yang menggunakan port 3000
lsof -ti:3000 | xargs kill -9

# Atau gunakan port lain
npm run dev -- -p 3001
```

#### 2. Prisma Client Error
```bash
# Regenerate Prisma client
npx prisma generate

# Reset database
npx prisma db push --force-reset
```

#### 3. Module Not Found Error
```bash
# Clear node_modules dan reinstall
rm -rf node_modules package-lock.json
npm install
```

#### 4. TypeScript Error
```bash
# Check TypeScript configuration
npx tsc --noEmit

# Update types
npm install --save-dev @types/node@latest
```

#### 5. Build Error
```bash
# Clear Next.js cache
rm -rf .next

# Rebuild
npm run build
```

---

## 📚 Panduan Maintenance

### Daily Operations
```bash
# Check server status
curl http://localhost:3000/api/health

# Backup database
cp prisma/dev.db backup/dev-$(date +%Y%m%d).db

# Check logs
tail -f dev.log
```

### Weekly Operations
```bash
# Update dependencies
npm update

# Security audit
npm audit

# Database maintenance
npx prisma db push
```

### Monthly Operations
```bash
# Major dependency updates
npm install next@latest @prisma/client@latest

# Database optimization
npx prisma db push --force-reset
# (backup sebelum melakukan ini!)
```

---

## 🚀 Deployment

### Development Deployment
```bash
# Build dan start
npm run build
npm start
```

### Production Deployment (Docker)
Buat `Dockerfile`:
```dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .
RUN npm run build

EXPOSE 3000

CMD ["npm", "start"]
```

Build dan run Docker:
```bash
docker build -t manajemen-aset-it .
docker run -p 3000:3000 manajemen-aset-it
```

---

## 📞 Support

### Resource Links
- **Next.js Documentation**: https://nextjs.org/docs
- **Prisma Documentation**: https://www.prisma.io/docs
- **Tailwind CSS**: https://tailwindcss.com/docs
- **shadcn/ui**: https://ui.shadcn.com/

### Common Issues
1. **Database Connection**: Pastikan file `dev.db` ada di folder `prisma`
2. **Environment Variables**: Check file `.env.local`
3. **Dependencies**: Run `npm install` setiap ada perubahan di `package.json`
4. **Port Issues**: Use port 3001 jika 3000 tidak available

---

## 🎉 Selamat! 🎉

Sistem Manajemen Aset IT Anda sudah siap digunakan! 

### Next Steps:
1. **Explore Features**: Coba semua fitur yang tersedia
2. **Add Sample Data**: Tambah data aset untuk testing
3. **Customize**: Sesuaikan dengan kebutuhan perusahaan
4. **Backup Setup**: Setup backup database rutin
5. **User Training**: Training untuk tim yang akan menggunakan sistem

### Need Help?
- Check documentation di dalam code
- Review error messages di console
- Test API endpoints dengan Postman/Insomnia
- Join community forums untuk support

**Happy Coding! 🚀**